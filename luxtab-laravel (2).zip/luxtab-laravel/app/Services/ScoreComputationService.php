<?php

namespace App\Services;

use App\Models\AuditLog;
use App\Models\Deduction;
use App\Models\Event;
use App\Models\Institute;
use App\Models\Judge;
use App\Models\JudgeScoreEntry;
use App\Models\LeaderboardSnapshot;
use App\Models\Participant;
use App\Models\RankPointConfig;
use App\Models\ResultEntry;
use App\Models\Season;
use App\Models\User;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

/**
 * Implements the three-level computation model from Thesis Ch.4.4.1 and
 * Figure 12 (Computation and Ranking Flowchart), and the deduction
 * hierarchy from the ERD's DEDUCTION entity. Every public method below
 * is named after the thesis's own vocabulary for that step so the
 * mapping from paper to code is direct during defense.
 *
 *   Level 1 — Judge Total       (criteria-based events only)
 *   Level 2 — Event Score       (all events; ranked within the event)
 *   Level 3 — Overall Score     (category-weighted, across a season)
 */
class ScoreComputationService
{
    // =================================================================
    // LEVEL 1 — Judge Total
    // =================================================================

    /**
     * Judge Total for one judge scoring one participant: the
     * criterion-allocated sum of that judge's raw scores (each
     * criterion's max_score already *is* its weight — see
     * scoring_criteria migration — so no multiplication step exists),
     * less any judge-level deductions against that participant from
     * that judge.
     */
    public function judgeTotal(Judge $judge, Participant $participant): float
    {
        $raw = JudgeScoreEntry::where('judge_id', $judge->id)
            ->where('participant_id', $participant->participant_id)
            ->sum('raw_score');

        $deducted = Deduction::where('level', Deduction::LEVEL_JUDGE)
            ->where('judge_id', $judge->id)
            ->where('participant_id', $participant->participant_id)
            ->sum('value');

        return round((float) $raw - (float) $deducted, 2);
    }

    // =================================================================
    // LEVEL 2 — Event Score
    // =================================================================

    /**
     * Event Score (Level 2) for one participant, before ranking:
     *   - criteria_based events: the average of every judge's Judge
     *     Total who has scored this participant.
     *   - by_round events: the Tabulator-entered ResultEntry.overall_score.
     * Event-level deductions are subtracted last, after judges are
     * averaged (per Ch.4.4.1's deduction-ordering description).
     */
    public function eventScoreForParticipant(Event $event, Participant $participant): float
    {
        if ($event->isCriteriaBased()) {
            $judgeIds = JudgeScoreEntry::where('event_id', $event->event_id)
                ->where('participant_id', $participant->participant_id)
                ->distinct()
                ->pluck('judge_id');

            $judges = Judge::whereIn('id', $judgeIds)->get();

            $raw = $judges->isEmpty()
                ? 0.0
                : $judges->avg(fn (Judge $judge) => $this->judgeTotal($judge, $participant));
        } else {
            $raw = (float) (ResultEntry::where('event_id', $event->event_id)
                ->where('participant_id', $participant->participant_id)
                ->value('overall_score') ?? 0);
        }

        $eventDeductions = Deduction::where('level', Deduction::LEVEL_EVENT)
            ->where('event_id', $event->event_id)
            ->where('participant_id', $participant->participant_id)
            ->sum('value');

        return round($raw - (float) $eventDeductions, 4);
    }

    /**
     * Recomputes Level 2 for every participant in the event, ranks them
     * (standard competition ranking — ties share a rank, the next rank
     * skips accordingly), and upserts one leaderboard_snapshots row per
     * participant scoped to this event. Matches the ERD note that
     * snapshots are only ever written by the system, never hand-edited.
     *
     * @return Collection<int, array{institute_id: int, score: float, rank: int}>
     */
    public function recomputeEventStandings(Event $event): Collection
    {
        return DB::transaction(function () use ($event) {
            // Standings/Overall Score are scoped to TCGC's institutes (the
            // thesis's actual competing units — see Ch.1). A participant
            // row without an institute_id (team/individual participation,
            // kept as an additive data-model option) has no institute to
            // roll up into and is intentionally excluded here rather than
            // colliding under a null key.
            $participants = $event->participants()->with('institute')->whereNotNull('institute_id')->get();

            $scoresByInstitute = $participants->mapWithKeys(
                fn (Participant $p) => [$p->institute_id => $this->eventScoreForParticipant($event, $p)]
            );

            $ranks = $this->computeRanks($scoresByInstitute->all());
            $now = now();

            foreach ($participants as $participant) {
                LeaderboardSnapshot::updateOrCreate(
                    [
                        'season_id' => $event->season_id,
                        'event_id' => $event->event_id,
                        'institute_id' => $participant->institute_id,
                    ],
                    [
                        'participant_id' => $participant->participant_id,
                        'computed_score' => $scoresByInstitute[$participant->institute_id],
                        'rank' => $ranks[$participant->institute_id],
                        'is_visible' => $event->leaderboard_visible,
                        'updated_at' => $now,
                        'created_at' => $now,
                    ]
                );
            }

            return $participants->map(fn (Participant $p) => [
                'institute_id' => $p->institute_id,
                'institute' => $p->institute?->name,
                'score' => $scoresByInstitute[$p->institute_id],
                'rank' => $ranks[$p->institute_id],
            ])->sortBy('rank')->values();
        });
    }

    /**
     * Converts an event rank to a point value via that event's
     * configured rank_point_configs table (Ch.4.4.1: "the event rank
     * earned at Level 2 is converted to a point value using a
     * configured conversion table"). Ranks with no configured row are
     * worth 0 points.
     */
    public function convertRankToPoints(Event $event, ?int $rank): float
    {
        if (is_null($rank)) {
            return 0.0;
        }

        return (float) (RankPointConfig::where('event_id', $event->event_id)
            ->where('rank_position', $rank)
            ->value('points') ?? 0);
    }

    // =================================================================
    // LEVEL 3 — Overall Score
    // =================================================================

    /**
     * Recomputes Level 3 for every institute with a standing in this
     * season: Overall Score = Σ(event input × category weight) − overall
     * deductions, where "event input" is a rank-converted point value
     * for rank_based events or the raw Event Score for points_based
     * events (Ch.4.4.1). Only finalized events contribute, matching the
     * ERD note that standings are "generated dynamically from validated
     * source scores" — i.e. from confirmed Level-2 snapshots, not live
     * in-progress ones.
     *
     * @return Collection<int, array{institute_id: int, score: float, rank: int}>
     */
    public function recomputeSeasonStandings(Season $season): Collection
    {
        return DB::transaction(function () use ($season) {
            $finalizedEvents = $season->events()
                ->where('is_finalized', true)
                ->with('category')
                ->get();

            /** @var array<int, float> $contributions institute_id => running Overall Score */
            $contributions = [];

            foreach ($finalizedEvents as $event) {
                $weight = ((float) $event->category->weight_pct) / 100;

                $snapshots = LeaderboardSnapshot::forEvent($event->event_id)->get();

                foreach ($snapshots as $snapshot) {
                    $levelInput = $event->isRankBased()
                        ? $this->convertRankToPoints($event, $snapshot->rank)
                        : (float) $snapshot->computed_score;

                    $contributions[$snapshot->institute_id] =
                        ($contributions[$snapshot->institute_id] ?? 0) + ($levelInput * $weight);
                }
            }

            $overallDeductions = Deduction::where('level', Deduction::LEVEL_OVERALL)
                ->where('season_id', $season->id)
                ->selectRaw('institute_id, SUM(value) as total')
                ->groupBy('institute_id')
                ->pluck('total', 'institute_id');

            $finalScores = [];
            foreach ($contributions as $instituteId => $raw) {
                $finalScores[$instituteId] = round($raw - (float) ($overallDeductions[$instituteId] ?? 0), 4);
            }

            $ranks = $this->computeRanks($finalScores);
            $now = now();

            foreach ($finalScores as $instituteId => $score) {
                LeaderboardSnapshot::updateOrCreate(
                    ['season_id' => $season->id, 'event_id' => null, 'institute_id' => $instituteId],
                    ['computed_score' => $score, 'rank' => $ranks[$instituteId], 'updated_at' => $now, 'created_at' => $now]
                );
            }

            return collect($finalScores)->map(fn ($score, $instituteId) => [
                'institute_id' => $instituteId,
                'institute' => Institute::find($instituteId)?->name,
                'score' => $score,
                'rank' => $ranks[$instituteId],
            ])->sortBy('rank')->values();
        });
    }

    // =================================================================
    // Workflow actions (finalize, deductions, visibility)
    // =================================================================

    /**
     * Use Case "Finalize Standings": locks Level 1/2 inputs for this
     * event, writes its leaderboard_snapshots, then cascades into a
     * Level 3 recompute for the whole season since this event may now
     * contribute to the Overall Score.
     */
    public function finalizeEvent(Event $event, User $tabulator): Collection
    {
        return DB::transaction(function () use ($event, $tabulator) {
            $standings = $this->recomputeEventStandings($event);

            $event->update([
                'is_finalized' => true,
                'finalized_at' => now(),
                'finalized_by' => $tabulator->user_id,
                'status' => 'completed',
            ]);

            $this->recomputeSeasonStandings($event->season);

            AuditLog::record(
                $tabulator->user_id,
                'event.finalized',
                'Event',
                $event->event_id,
                notes: "Finalized standings for \"{$event->name}\"."
            );

            return $standings;
        });
    }

    /** Reopens a finalized event (e.g. to correct a score) and cascades the season recompute. */
    public function unfinalizeEvent(Event $event, User $tabulator): void
    {
        DB::transaction(function () use ($event, $tabulator) {
            $event->update(['is_finalized' => false, 'finalized_at' => null, 'finalized_by' => null, 'status' => 'ongoing']);
            $this->recomputeSeasonStandings($event->season);

            AuditLog::record($tabulator->user_id, 'event.reopened', 'Event', $event->event_id);
        });
    }

    /** Use Case "Toggle Leaderboard Visibility". */
    public function setLeaderboardVisibility(Event $event, bool $visible, User $actor): void
    {
        DB::transaction(function () use ($event, $visible, $actor) {
            $event->update(['leaderboard_visible' => $visible]);
            LeaderboardSnapshot::forEvent($event->event_id)->update(['is_visible' => $visible]);

            AuditLog::record(
                $actor->user_id,
                $visible ? 'leaderboard.shown' : 'leaderboard.hidden',
                'Event',
                $event->event_id
            );
        });
    }

    /**
     * Use Case "Apply Deductions". `$participant` is required for
     * judge/event level (identifies which event participant row this
     * ties to) and ignored for overall level, which is keyed purely by
     * institute + season.
     */
    public function applyDeduction(
        Institute $institute,
        Season $season,
        string $level,
        float $value,
        string $reason,
        User $tabulator,
        ?Event $event = null,
        ?Participant $participant = null,
        ?Judge $judge = null,
    ): Deduction {
        if (! in_array($level, [Deduction::LEVEL_JUDGE, Deduction::LEVEL_EVENT, Deduction::LEVEL_OVERALL], true)) {
            throw new \InvalidArgumentException("Invalid deduction level: {$level}");
        }

        if (in_array($level, [Deduction::LEVEL_JUDGE, Deduction::LEVEL_EVENT], true) && (! $event || ! $participant)) {
            throw new \InvalidArgumentException("Deduction level '{$level}' requires both an event and a participant.");
        }

        if ($level === Deduction::LEVEL_JUDGE && ! $judge) {
            throw new \InvalidArgumentException("Deduction level 'judge' requires a judge.");
        }

        return DB::transaction(function () use ($institute, $season, $level, $value, $reason, $tabulator, $event, $participant, $judge) {
            $deduction = Deduction::create([
                'season_id' => $season->id,
                'event_id' => $event?->event_id,
                'institute_id' => $institute->id,
                'participant_id' => $participant?->participant_id,
                'tabulator_id' => $tabulator->user_id,
                'judge_id' => $judge?->id,
                'level' => $level,
                'value' => $value,
                'reason' => $reason,
            ]);

            $this->recomputeAfterDeductionChange($deduction);

            AuditLog::record(
                $tabulator->user_id,
                'deduction.applied',
                'Deduction',
                $deduction->deduction_id,
                new: $deduction->only(['level', 'value', 'reason']),
                notes: "{$value} pts against {$institute->name} ({$level} level): {$reason}"
            );

            return $deduction;
        });
    }

    public function removeDeduction(Deduction $deduction, User $actor): void
    {
        DB::transaction(function () use ($deduction, $actor) {
            $snapshot = $deduction->only(['level', 'value', 'reason', 'institute_id', 'event_id', 'season_id']);
            $deduction->delete();
            $this->recomputeAfterDeductionChange((object) $snapshot);

            AuditLog::record($actor->user_id, 'deduction.removed', 'Deduction', null, old: $snapshot);
        });
    }

    private function recomputeAfterDeductionChange(object $deduction): void
    {
        if ($deduction->level === Deduction::LEVEL_OVERALL) {
            $this->recomputeSeasonStandings(Season::findOrFail($deduction->season_id));

            return;
        }

        // judge or event level: both live inside one event, so
        // recomputing that event's standings and cascading to the
        // season covers either case.
        $event = Event::findOrFail($deduction->event_id);
        $this->recomputeEventStandings($event);
        $this->recomputeSeasonStandings($event->season);
    }

    // =================================================================
    // Shared helpers
    // =================================================================

    /**
     * Standard competition ("1224") ranking: ties share the same rank
     * and the next distinct score skips to its true position rather
     * than the next integer.
     *
     * @param  array<int, float>  $scoresByKey
     * @return array<int, int>
     */
    private function computeRanks(array $scoresByKey): array
    {
        $sorted = $scoresByKey;
        arsort($sorted);

        $ranks = [];
        $position = 0;
        $lastScore = null;
        $lastRank = 0;

        foreach ($sorted as $key => $score) {
            $position++;
            if ($lastScore === null || abs($score - $lastScore) > 0.0001) {
                $lastRank = $position;
            }
            $ranks[$key] = $lastRank;
            $lastScore = $score;
        }

        return $ranks;
    }
}
