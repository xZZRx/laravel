<?php

namespace App\Services;

use App\Models\AuditLog;
use App\Models\Event;
use App\Models\GameMatch;
use App\Models\Participant;
use App\Models\Tournament;
use App\Models\User;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

/**
 * Module 3 "Automated Bracket Generation" / Use Case "Create Tournament
 * Brackets". Restricted to the thesis's three documented formats
 * (single elimination, double elimination, round robin — see
 * tournaments migration).
 */
class BracketGenerationService
{
    public function generate(Event $event, string $format, Collection $participants, User $creator, bool $seeded = false): Tournament
    {
        return DB::transaction(function () use ($event, $format, $participants, $creator, $seeded) {
            $event->tournament()?->delete(); // regenerating replaces any prior bracket

            $tournament = Tournament::create([
                'event_id' => $event->event_id,
                'format' => $format,
                'is_seeded' => $seeded,
                'created_by' => $creator->user_id,
            ]);

            match ($format) {
                Tournament::FORMAT_SINGLE_ELIM => $this->generateSingleElimination($tournament, $participants),
                Tournament::FORMAT_DOUBLE_ELIM => $this->generateDoubleElimination($tournament, $participants),
                Tournament::FORMAT_ROUND_ROBIN => $this->generateRoundRobin($tournament, $participants),
                default => throw new \InvalidArgumentException("Unsupported format: {$format}"),
            };

            AuditLog::record($creator->user_id, 'tournament.generated', 'Tournament', $tournament->tournament_id,
                notes: "Generated a {$format} bracket for \"{$event->name}\" with {$participants->count()} participants.");

            return $tournament->fresh('matches');
        });
    }

    // -----------------------------------------------------------------
    // Single elimination
    // -----------------------------------------------------------------

    private function generateSingleElimination(Tournament $tournament, Collection $participants): void
    {
        $slots = $this->seedIntoBracket($participants);
        $bracketSize = count($slots);
        $totalRounds = (int) log($bracketSize, 2);
        $tournament->update(['total_rounds' => $totalRounds]);

        // Round 1: pair up seeded slots (nulls are byes).
        $roundMatches = [];
        $matchNumber = 1;
        for ($i = 0; $i < $bracketSize; $i += 2) {
            /** @var Participant|null $a */
            $a = $slots[$i];
            /** @var Participant|null $b */
            $b = $slots[$i + 1];
            $isBye = is_null($a) || is_null($b);

            $roundMatches[] = GameMatch::create([
                'tournament_id' => $tournament->tournament_id,
                'round_number' => 1,
                'match_number' => $matchNumber++,
                'participant_a_id' => $a?->participant_id,
                'participant_b_id' => $b?->participant_id,
                'winner_id' => $isBye ? ($a?->participant_id ?? $b?->participant_id) : null,
                'status' => $isBye ? GameMatch::STATUS_COMPLETED : GameMatch::STATUS_SCHEDULED,
                'is_bye' => $isBye,
            ]);
        }

        // Subsequent rounds: empty shells wired via next_match_id/slot so
        // recordResult() can auto-advance winners.
        $previousRound = collect($roundMatches);
        for ($round = 2; $round <= $totalRounds; $round++) {
            $matchNumber = 1;
            $thisRound = collect();

            foreach ($previousRound->chunk(2) as $pair) {
                $match = GameMatch::create([
                    'tournament_id' => $tournament->tournament_id,
                    'round_number' => $round,
                    'match_number' => $matchNumber++,
                    'status' => GameMatch::STATUS_SCHEDULED,
                ]);
                $thisRound->push($match);

                $slotAssignments = ['a', 'b'];
                foreach ($pair->values() as $i => $feederMatch) {
                    $feederMatch->update(['next_match_id' => $match->match_id, 'next_match_slot' => $slotAssignments[$i]]);
                }
            }

            $previousRound = $thisRound;
        }

        // Propagate round-1 byes into round 2 immediately.
        $this->propagateByes($tournament);
    }

    /**
     * Standard bracket seed order (keeps seed 1 and 2 on opposite halves,
     * seeds 1–4 in separate quarters, etc.) padded to the next power of
     * two with byes. Participants are seeded in the order passed in —
     * pass them pre-sorted if you want seeding to mean something beyond
     * "spread the bracket evenly."
     *
     * @return array<int, Participant|null>
     */
    private function seedIntoBracket(Collection $participants): array
    {
        $n = $participants->count();
        $bracketSize = max(2, 2 ** ceil(log(max($n, 1), 2)));
        $order = $this->standardSeedOrder($bracketSize); // 1-indexed seed positions

        $slots = array_fill(0, $bracketSize, null);
        $values = $participants->values();

        foreach ($order as $position => $seed) {
            $slots[$position] = $values->get($seed - 1); // null when seed > $n (a bye)
        }

        return $slots;
    }

    /** @return array<int, int> position (0-indexed) => seed number (1-indexed) */
    private function standardSeedOrder(int $size): array
    {
        $build = function (int $size) use (&$build): array {
            if ($size === 1) {
                return [1];
            }
            $prev = $build($size / 2);
            $result = [];
            foreach ($prev as $seed) {
                $result[] = $seed;
                $result[] = $size + 1 - $seed;
            }

            return $result;
        };

        return array_values($build($size));
    }

    private function propagateByes(Tournament $tournament): void
    {
        $byeMatches = $tournament->matches()->where('is_bye', true)->whereNotNull('next_match_id')->get();

        foreach ($byeMatches as $match) {
            $this->advanceWinner($match, $match->winner_id);
        }
    }

    // -----------------------------------------------------------------
    // Round robin
    // -----------------------------------------------------------------

    private function generateRoundRobin(Tournament $tournament, Collection $participants): void
    {
        $players = $participants->values()->all();
        if (count($players) % 2 !== 0) {
            $players[] = null; // bye slot
        }
        $n = count($players);
        $totalRounds = $n - 1;
        $tournament->update(['total_rounds' => $totalRounds]);

        for ($round = 1; $round <= $totalRounds; $round++) {
            $matchNumber = 1;
            for ($i = 0; $i < $n / 2; $i++) {
                /** @var Participant|null $a */
                $a = $players[$i];
                /** @var Participant|null $b */
                $b = $players[$n - 1 - $i];

                if ($a && $b) {
                    GameMatch::create([
                        'tournament_id' => $tournament->tournament_id,
                        'round_number' => $round,
                        'match_number' => $matchNumber++,
                        'participant_a_id' => $a->participant_id,
                        'participant_b_id' => $b->participant_id,
                        'status' => GameMatch::STATUS_SCHEDULED,
                    ]);
                }
            }

            // Circle method: keep index 0 fixed, rotate the rest.
            $fixed = $players[0];
            $rest = array_slice($players, 1);
            array_unshift($rest, array_pop($rest));
            $players = array_merge([$fixed], $rest);
        }
    }

    // -----------------------------------------------------------------
    // Double elimination (winners bracket auto-generated identically to
    // single elimination; the losers bracket is created with the correct
    // number of rounds/slots but left for the Tournament Manager to seed
    // manually as winners-bracket losers come in — full automatic
    // cross-bracket advancement is the one piece of Module 3 this build
    // simplifies. Flagged clearly in the project README.)
    // -----------------------------------------------------------------

    private function generateDoubleElimination(Tournament $tournament, Collection $participants): void
    {
        $this->generateSingleElimination($tournament, $participants);

        $winnersRounds = (int) $tournament->total_rounds;
        $loserRounds = max(1, ($winnersRounds - 1) * 2);
        $bracketSize = 2 ** $winnersRounds;

        $matchNumber = 1;
        $slotsInRound = $bracketSize / 4;
        for ($round = 1; $round <= $loserRounds && $slotsInRound >= 1; $round++) {
            for ($i = 0; $i < max(1, $slotsInRound); $i++) {
                GameMatch::create([
                    'tournament_id' => $tournament->tournament_id,
                    'round_number' => $winnersRounds + $round, // stored after winners-bracket rounds
                    'match_number' => $matchNumber++,
                    'status' => GameMatch::STATUS_SCHEDULED,
                    'notes' => 'Losers bracket — seed manually as winners-bracket losers are decided.',
                ]);
            }
            if ($round % 2 === 0) {
                $slotsInRound = (int) ($slotsInRound / 2);
            }
        }
    }

    // -----------------------------------------------------------------
    // Result recording / auto-advance
    // -----------------------------------------------------------------

    public function recordResult(GameMatch $match, ?int $winnerId, ?float $scoreA, ?float $scoreB, ?string $scoreAText = null, ?string $scoreBText = null): void
    {
        DB::transaction(function () use ($match, $winnerId, $scoreA, $scoreB, $scoreAText, $scoreBText) {
            $match->update([
                'winner_id' => $winnerId,
                'score_a' => $scoreA,
                'score_b' => $scoreB,
                'score_a_text' => $scoreAText,
                'score_b_text' => $scoreBText,
                'status' => GameMatch::STATUS_COMPLETED,
            ]);

            $this->advanceWinner($match, $winnerId);
        });
    }

    private function advanceWinner(GameMatch $match, ?int $winnerId): void
    {
        if (! $match->next_match_id || ! $winnerId) {
            return;
        }

        $next = GameMatch::find($match->next_match_id);
        if (! $next) {
            return;
        }

        $column = $match->next_match_slot === 'b' ? 'participant_b_id' : 'participant_a_id';
        $next->update([$column => $winnerId]);
    }
}
