<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class JudgeScoreEntry extends Model
{
    use HasFactory;

    protected $table = 'judge_score_entries';

    protected $primaryKey = 'entry_id';

    protected $fillable = [
        'event_id', 'judge_id', 'participant_id', 'criterion_id',
        'raw_score', 'weighted_score', 'signature', 'submitted_at',
    ];

    protected function casts(): array
    {
        return [
            'raw_score' => 'decimal:2',
            'weighted_score' => 'decimal:2',
            'submitted_at' => 'datetime',
        ];
    }

    public function event(): BelongsTo
    {
        return $this->belongsTo(Event::class, 'event_id');
    }

    public function judge(): BelongsTo
    {
        return $this->belongsTo(Judge::class, 'judge_id');
    }

    public function participant(): BelongsTo
    {
        return $this->belongsTo(Participant::class, 'participant_id', 'participant_id');
    }

    public function criterion(): BelongsTo
    {
        return $this->belongsTo(ScoringCriterion::class, 'criterion_id', 'criterion_id');
    }
}
