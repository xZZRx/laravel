<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Tournament extends Model
{
    use HasFactory;

    const FORMAT_SINGLE_ELIM = 'single_elimination';

    const FORMAT_DOUBLE_ELIM = 'double_elimination';

    const FORMAT_ROUND_ROBIN = 'round_robin';

    protected $primaryKey = 'tournament_id';

    protected $fillable = ['event_id', 'format', 'total_rounds', 'is_seeded', 'created_by'];

    protected function casts(): array
    {
        return ['is_seeded' => 'boolean'];
    }

    public function event(): BelongsTo
    {
        return $this->belongsTo(Event::class, 'event_id');
    }

    public function createdBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by', 'user_id');
    }

    public function matches(): HasMany
    {
        return $this->hasMany(GameMatch::class, 'tournament_id')->orderBy('round_number')->orderBy('match_number');
    }
}
