<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Judge extends Model
{
    use HasFactory;

    protected $fillable = ['event_id', 'user_id', 'name', 'title', 'submitted_at', 'sort_order'];

    protected function casts(): array
    {
        return ['submitted_at' => 'datetime'];
    }

    public function event(): BelongsTo
    {
        return $this->belongsTo(Event::class, 'event_id');
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id', 'user_id');
    }

    public function scoreEntries(): HasMany
    {
        return $this->hasMany(JudgeScoreEntry::class, 'judge_id');
    }

    public function deductions(): HasMany
    {
        return $this->hasMany(Deduction::class, 'judge_id');
    }

    public function isGuest(): bool
    {
        return is_null($this->user_id);
    }

    public function hasSubmitted(): bool
    {
        return ! is_null($this->submitted_at);
    }
}
