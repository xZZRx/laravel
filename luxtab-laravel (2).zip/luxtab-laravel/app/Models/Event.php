<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\SoftDeletes;

class Event extends Model
{
    use HasFactory, SoftDeletes;

    protected $primaryKey = 'event_id';

    protected $fillable = [
        'season_id', 'event_category_id', 'name', 'slug', 'description',
        'type', 'participation_type', 'scoring_type', 'scoring_method',
        'status', 'organizer_id', 'tabulator_id', 'venue', 'schedule',
        'rescheduled_from', 'reschedule_reason', 'reschedule_count',
        'leaderboard_visible', 'is_finalized', 'finalized_at', 'finalized_by',
    ];

    protected function casts(): array
    {
        return [
            'schedule' => 'datetime',
            'rescheduled_from' => 'datetime',
            'leaderboard_visible' => 'boolean',
            'is_finalized' => 'boolean',
            'finalized_at' => 'datetime',
        ];
    }

    // --- Relationships -----------------------------------------------

    public function season(): BelongsTo
    {
        return $this->belongsTo(Season::class);
    }

    public function category(): BelongsTo
    {
        return $this->belongsTo(EventCategory::class, 'event_category_id');
    }

    public function organizer(): BelongsTo
    {
        return $this->belongsTo(User::class, 'organizer_id', 'user_id');
    }

    public function tabulator(): BelongsTo
    {
        return $this->belongsTo(User::class, 'tabulator_id', 'user_id');
    }

    public function finalizer(): BelongsTo
    {
        return $this->belongsTo(User::class, 'finalized_by', 'user_id');
    }

    /** Additional Tabulators beyond the primary `tabulator_id`. */
    public function tabulators(): BelongsToMany
    {
        return $this->belongsToMany(User::class, 'event_tabulators', 'event_id', 'user_id', 'event_id', 'user_id');
    }

    public function tournamentManagers(): BelongsToMany
    {
        return $this->belongsToMany(User::class, 'event_tournament_managers', 'event_id', 'user_id', 'event_id', 'user_id');
    }

    public function scoringCriteria(): HasMany
    {
        return $this->hasMany(ScoringCriterion::class, 'event_id')->whereNull('parent_id')->orderBy('sort_order');
    }

    public function allScoringCriteria(): HasMany
    {
        return $this->hasMany(ScoringCriterion::class, 'event_id');
    }

    public function participants(): HasMany
    {
        return $this->hasMany(Participant::class, 'event_id');
    }

    public function judges(): HasMany
    {
        return $this->hasMany(Judge::class, 'event_id')->orderBy('sort_order');
    }

    public function judgeScoreEntries(): HasMany
    {
        return $this->hasMany(JudgeScoreEntry::class, 'event_id');
    }

    public function resultEntries(): HasMany
    {
        return $this->hasMany(ResultEntry::class, 'event_id');
    }

    public function deductions(): HasMany
    {
        return $this->hasMany(Deduction::class, 'event_id');
    }

    public function rankPointConfigs(): HasMany
    {
        return $this->hasMany(RankPointConfig::class, 'event_id')->orderBy('rank_position');
    }

    public function tournament(): HasOne
    {
        return $this->hasOne(Tournament::class, 'event_id');
    }

    public function leaderboardSnapshots(): HasMany
    {
        return $this->hasMany(LeaderboardSnapshot::class, 'event_id');
    }

    // --- Thesis-terminology accessors ---------------------------------
    // Named to match Module 4 / Ch.4.4.1 vocabulary exactly, so the
    // code a panelist reads uses the same words as the paper.

    public function isCriteriaBased(): bool
    {
        return $this->scoring_type === 'criteria_based';
    }

    public function isByRound(): bool
    {
        return $this->scoring_type === 'by_round';
    }

    public function isRankBased(): bool
    {
        return $this->scoring_method === 'rank_based';
    }

    public function isPointsBased(): bool
    {
        return $this->scoring_method === 'points_based';
    }

    /** Sum of all top-level scoring criteria max_score (should equal 100). */
    public function criteriaWeightTotal(): float
    {
        return (float) $this->scoringCriteria()->sum('max_score');
    }
}
