<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * ERD: MATCH(match_id, tournament_id, round_number, participant_a_id,
 * participant_b_id, winner_id, score_a, score_b, status, match_date,
 * venue). Named `GameMatch` because `match` has been a reserved word in
 * PHP since 8.0 (used for match expressions) and cannot name a class.
 */
class GameMatch extends Model
{
    use HasFactory;

    protected $table = 'matches';

    protected $primaryKey = 'match_id';

    const STATUS_SCHEDULED = 'scheduled';

    const STATUS_ONGOING = 'ongoing';

    const STATUS_COMPLETED = 'completed';

    protected $fillable = [
        'tournament_id', 'round_number', 'match_number',
        'participant_a_id', 'participant_b_id', 'winner_id',
        'score_a', 'score_b', 'score_a_text', 'score_b_text',
        'status', 'match_date', 'venue', 'rescheduled_from',
        'reschedule_reason', 'is_bye', 'notes', 'next_match_id', 'next_match_slot',
    ];

    protected function casts(): array
    {
        return [
            'match_date' => 'datetime',
            'rescheduled_from' => 'datetime',
            'is_bye' => 'boolean',
            'score_a' => 'decimal:2',
            'score_b' => 'decimal:2',
        ];
    }

    public function tournament(): BelongsTo
    {
        return $this->belongsTo(Tournament::class, 'tournament_id', 'tournament_id');
    }

    public function participantA(): BelongsTo
    {
        return $this->belongsTo(Participant::class, 'participant_a_id', 'participant_id');
    }

    public function participantB(): BelongsTo
    {
        return $this->belongsTo(Participant::class, 'participant_b_id', 'participant_id');
    }

    public function winner(): BelongsTo
    {
        return $this->belongsTo(Participant::class, 'winner_id', 'participant_id');
    }

    public function nextMatch(): BelongsTo
    {
        return $this->belongsTo(self::class, 'next_match_id', 'match_id');
    }

    public function isComplete(): bool
    {
        return $this->status === self::STATUS_COMPLETED;
    }
}
