<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Participant extends Model
{
    use HasFactory;

    protected $primaryKey = 'participant_id';

    protected $fillable = ['event_id', 'institute_id', 'name', 'is_disqualified'];

    protected function casts(): array
    {
        return ['is_disqualified' => 'boolean'];
    }

    public function event(): BelongsTo
    {
        return $this->belongsTo(Event::class, 'event_id');
    }

    public function institute(): BelongsTo
    {
        return $this->belongsTo(Institute::class);
    }

    public function judgeScoreEntries(): HasMany
    {
        return $this->hasMany(JudgeScoreEntry::class, 'participant_id', 'participant_id');
    }

    public function resultEntry(): HasMany
    {
        return $this->hasMany(ResultEntry::class, 'participant_id', 'participant_id');
    }

    public function deductions(): HasMany
    {
        return $this->hasMany(Deduction::class, 'participant_id', 'participant_id');
    }

    public function leaderboardSnapshots(): HasMany
    {
        return $this->hasMany(LeaderboardSnapshot::class, 'participant_id', 'participant_id');
    }
}
