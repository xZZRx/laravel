<?php

namespace App\Models;

use App\Enums\Role;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    use HasFactory, Notifiable;

    protected $primaryKey = 'user_id';

    protected $fillable = [
        'name', 'username', 'email', 'password', 'role',
        'institute_id', 'avatar_path', 'is_active',
    ];

    protected $hidden = [
        'password', 'remember_token',
    ];

    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
            'role' => Role::class,
            'is_active' => 'boolean',
            'last_login_at' => 'datetime',
        ];
    }

    public function institute(): BelongsTo
    {
        return $this->belongsTo(Institute::class);
    }

    public function organizedEvents(): HasMany
    {
        return $this->hasMany(Event::class, 'organizer_id');
    }

    public function tabulatedEvents(): HasMany
    {
        return $this->hasMany(Event::class, 'tabulator_id');
    }

    /** Additional events assigned via the event_tabulators pivot. */
    public function assistingTabulatorEvents()
    {
        return $this->belongsToMany(Event::class, 'event_tabulators', 'user_id', 'event_id');
    }

    public function assistingTournamentManagerEvents()
    {
        return $this->belongsToMany(Event::class, 'event_tournament_managers', 'user_id', 'event_id');
    }

    public function auditLogs(): HasMany
    {
        return $this->hasMany(AuditLog::class);
    }

    public function hasRole(Role|string $role): bool
    {
        $value = $role instanceof Role ? $role->value : $role;

        return $this->role?->value === $value;
    }

    public function hasAnyRole(array $roles): bool
    {
        return in_array($this->role?->value, array_map(
            fn ($r) => $r instanceof Role ? $r->value : $r,
            $roles
        ), true);
    }

    /**
     * Whether this user can act as Tabulator on the given event — either
     * as the primary tabulator_id or an additional assigned Tabulator.
     */
    public function canTabulate(Event $event): bool
    {
        if ($this->hasRole(Role::Admin)) {
            return false; // Admin has no event-level access (thesis: user-account management only).
        }

        return $event->tabulator_id === $this->user_id
            || $event->tabulators()->where('users.user_id', $this->user_id)->exists();
    }

    public function canManageTournament(Event $event): bool
    {
        return $this->hasRole(Role::Admin) === false && (
            $this->hasRole(Role::TournamentManager)
            && $event->tournamentManagers()->where('users.user_id', $this->user_id)->exists()
        );
    }
}
