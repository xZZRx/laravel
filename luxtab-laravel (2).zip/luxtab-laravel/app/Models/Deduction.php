<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Deduction extends Model
{
    use HasFactory;

    const LEVEL_JUDGE = 'judge';

    const LEVEL_EVENT = 'event';

    const LEVEL_OVERALL = 'overall';

    protected $primaryKey = 'deduction_id';

    protected $fillable = [
        'season_id', 'event_id', 'institute_id', 'participant_id', 'tabulator_id', 'judge_id',
        'level', 'value', 'reason',
    ];

    protected function casts(): array
    {
        return ['value' => 'decimal:2'];
    }

    public function event(): BelongsTo
    {
        return $this->belongsTo(Event::class, 'event_id');
    }

    public function season(): BelongsTo
    {
        return $this->belongsTo(Season::class);
    }

    public function institute(): BelongsTo
    {
        return $this->belongsTo(Institute::class);
    }

    public function participant(): BelongsTo
    {
        return $this->belongsTo(Participant::class, 'participant_id', 'participant_id');
    }

    public function tabulator(): BelongsTo
    {
        return $this->belongsTo(User::class, 'tabulator_id', 'user_id');
    }

    public function judge(): BelongsTo
    {
        return $this->belongsTo(Judge::class, 'judge_id');
    }
}
