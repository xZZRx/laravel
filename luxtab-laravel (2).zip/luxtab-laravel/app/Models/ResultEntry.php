<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ResultEntry extends Model
{
    use HasFactory;

    protected $primaryKey = 'result_id';

    protected $fillable = [
        'event_id', 'tabulator_id', 'participant_id',
        'overall_score', 'score_text', 'rank', 'entered_at',
    ];

    protected function casts(): array
    {
        return [
            'overall_score' => 'decimal:4',
            'entered_at' => 'datetime',
        ];
    }

    public function event(): BelongsTo
    {
        return $this->belongsTo(Event::class, 'event_id');
    }

    public function tabulator(): BelongsTo
    {
        return $this->belongsTo(User::class, 'tabulator_id', 'user_id');
    }

    public function participant(): BelongsTo
    {
        return $this->belongsTo(Participant::class, 'participant_id', 'participant_id');
    }
}
