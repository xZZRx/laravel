<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

/**
 * A weighted category within one program (LMC or ARSO). `weight_pct` is
 * the Level 3 category weight from Ch.4.4.1 (e.g. ARSO Academic = 30).
 */
class EventCategory extends Model
{
    use HasFactory;

    protected $fillable = [
        'program', 'name', 'slug', 'weight_pct', 'icon', 'sort_order',
    ];

    protected function casts(): array
    {
        return [
            'weight_pct' => 'decimal:2',
        ];
    }

    public function events(): HasMany
    {
        return $this->hasMany(Event::class, 'event_category_id');
    }

    public function scopeProgram($query, string $program)
    {
        return $query->where('program', $program);
    }
}
