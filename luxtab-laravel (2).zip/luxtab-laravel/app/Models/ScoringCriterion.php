<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class ScoringCriterion extends Model
{
    use HasFactory;

    protected $primaryKey = 'criterion_id';

    protected $fillable = ['event_id', 'parent_id', 'name', 'description', 'max_score', 'sort_order'];

    protected function casts(): array
    {
        return ['max_score' => 'decimal:2'];
    }

    public function event(): BelongsTo
    {
        return $this->belongsTo(Event::class, 'event_id');
    }

    public function parent(): BelongsTo
    {
        return $this->belongsTo(self::class, 'parent_id', 'criterion_id');
    }

    public function children(): HasMany
    {
        return $this->hasMany(self::class, 'parent_id', 'criterion_id')->orderBy('sort_order');
    }

    public function judgeScoreEntries(): HasMany
    {
        return $this->hasMany(JudgeScoreEntry::class, 'criterion_id', 'criterion_id');
    }
}
