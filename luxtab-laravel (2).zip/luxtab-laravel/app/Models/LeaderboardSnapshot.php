<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class LeaderboardSnapshot extends Model
{
    use HasFactory;

    protected $primaryKey = 'snapshot_id';

    public $timestamps = false; // only `updated_at` is meaningful here (see ERD); set manually in the service.

    protected $fillable = [
        'season_id', 'event_id', 'institute_id', 'participant_id',
        'computed_score', 'rank', 'is_visible', 'updated_at', 'created_at',
    ];

    protected function casts(): array
    {
        return [
            'computed_score' => 'decimal:4',
            'is_visible' => 'boolean',
            'updated_at' => 'datetime',
            'created_at' => 'datetime',
        ];
    }

    public function season(): BelongsTo
    {
        return $this->belongsTo(Season::class);
    }

    public function event(): BelongsTo
    {
        return $this->belongsTo(Event::class, 'event_id');
    }

    public function institute(): BelongsTo
    {
        return $this->belongsTo(Institute::class);
    }

    public function participant(): BelongsTo
    {
        return $this->belongsTo(Participant::class, 'participant_id', 'participant_id');
    }

    /** True when this row represents the season-wide Overall Score (Level 3), not one event. */
    public function isOverallScope(): bool
    {
        return is_null($this->event_id);
    }

    public function scopeOverall($query)
    {
        return $query->whereNull('event_id');
    }

    public function scopeForEvent($query, int $eventId)
    {
        return $query->where('event_id', $eventId);
    }

    public function scopeVisible($query)
    {
        return $query->where('is_visible', true);
    }
}
