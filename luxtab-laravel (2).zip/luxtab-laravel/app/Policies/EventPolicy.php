<?php

namespace App\Policies;

use App\Enums\Role;
use App\Models\Event;
use App\Models\User;

class EventPolicy
{
    public function viewAny(User $user): bool
    {
        return true; // filtered per-role in the controller query, not blocked outright
    }

    public function view(User $user, Event $event): bool
    {
        return true;
    }

    public function create(User $user): bool
    {
        return $user->hasRole(Role::Organizer);
    }

    public function update(User $user, Event $event): bool
    {
        return $user->hasRole(Role::Organizer) && $event->organizer_id === $user->user_id;
    }

    public function delete(User $user, Event $event): bool
    {
        return $this->update($user, $event) && ! $event->is_finalized;
    }

    public function score(User $user, Event $event): bool
    {
        return $user->hasRole(Role::Judge)
            && $event->judges()->where('user_id', $user->user_id)->exists();
    }

    public function tabulate(User $user, Event $event): bool
    {
        return $user->hasRole(Role::Tabulator) && $user->canTabulate($event);
    }

    public function manageTournament(User $user, Event $event): bool
    {
        return $user->hasRole(Role::TournamentManager) && $user->canManageTournament($event);
    }
}
