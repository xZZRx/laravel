<?php

namespace App\Enums;

/**
 * The six actors from the Use Case Diagram (Figure 15): Admin,
 * Organizer, Tournament Manager, Judge, Tabulator, Viewer.
 */
enum Role: string
{
    case Admin = 'admin';
    case Organizer = 'organizer';
    case TournamentManager = 'tournament_manager';
    case Judge = 'judge';
    case Tabulator = 'tabulator';
    case Viewer = 'viewer';

    public function label(): string
    {
        return match ($this) {
            self::Admin => 'Admin',
            self::Organizer => 'Organizer',
            self::TournamentManager => 'Tournament Manager',
            self::Judge => 'Judge',
            self::Tabulator => 'Tabulator',
            self::Viewer => 'Viewer',
        };
    }

    /**
     * Where each role lands after login (Use Case 1: "role-based
     * dashboard redirection").
     */
    public function dashboardRoute(): string
    {
        return match ($this) {
            self::Admin => 'admin.users.index',
            self::Viewer => 'leaderboard.index',
            default => 'dashboard',
        };
    }

    /** @return array<int, string> */
    public static function values(): array
    {
        return array_map(fn (self $r) => $r->value, self::cases());
    }
}
