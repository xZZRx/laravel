<?php

namespace App\Http\Controllers;

use App\Models\Deduction;
use App\Models\Event;
use App\Models\Institute;
use App\Models\Judge;
use App\Models\Season;
use App\Services\ScoreComputationService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class DeductionController extends Controller
{
    public function __construct(private ScoreComputationService $scores) {}

    public function store(Request $request, Event $event): RedirectResponse
    {
        if (! $request->user()->canTabulate($event)) {
            abort(403);
        }

        $validated = $request->validate([
            'institute_id' => ['required', 'exists:institutes,id'],
            'level' => ['required', Rule::in([Deduction::LEVEL_JUDGE, Deduction::LEVEL_EVENT, Deduction::LEVEL_OVERALL])],
            'judge_id' => ['required_if:level,'.Deduction::LEVEL_JUDGE, 'nullable', 'exists:judges,id'],
            'value' => ['required', 'numeric', 'min:0.01'],
            'reason' => ['required', 'string', 'max:1000'],
        ]);

        $institute = Institute::findOrFail($validated['institute_id']);
        $participant = null;

        if (in_array($validated['level'], [Deduction::LEVEL_JUDGE, Deduction::LEVEL_EVENT], true)) {
            $participant = $event->participants()->where('institute_id', $institute->id)->firstOrFail();
        }

        $this->scores->applyDeduction(
            institute: $institute,
            season: $event->season,
            level: $validated['level'],
            value: (float) $validated['value'],
            reason: $validated['reason'],
            tabulator: $request->user(),
            event: $validated['level'] !== Deduction::LEVEL_OVERALL ? $event : null,
            participant: $participant,
            judge: ! empty($validated['judge_id']) ? Judge::find($validated['judge_id']) : null,
        );

        return back()->with('success', 'Deduction applied.');
    }

    public function destroy(Request $request, Deduction $deduction): RedirectResponse
    {
        $event = $deduction->event_id ? Event::findOrFail($deduction->event_id) : null;

        $authorized = $event ? $request->user()->canTabulate($event) : $request->user()->hasRole(\App\Enums\Role::Tabulator);

        if (! $authorized) {
            abort(403);
        }

        $this->scores->removeDeduction($deduction, $request->user());

        return back()->with('success', 'Deduction removed.');
    }

    /** Overall-level deductions aren't tied to one event, so they get their own entry point. */
    public function storeOverall(Request $request, Season $season): RedirectResponse
    {
        if (! $request->user()->hasRole(\App\Enums\Role::Tabulator)) {
            abort(403);
        }

        $validated = $request->validate([
            'institute_id' => ['required', 'exists:institutes,id'],
            'value' => ['required', 'numeric', 'min:0.01'],
            'reason' => ['required', 'string', 'max:1000'],
        ]);

        $this->scores->applyDeduction(
            institute: Institute::findOrFail($validated['institute_id']),
            season: $season,
            level: Deduction::LEVEL_OVERALL,
            value: (float) $validated['value'],
            reason: $validated['reason'],
            tabulator: $request->user(),
        );

        return back()->with('success', 'Overall-level deduction applied.');
    }
}
