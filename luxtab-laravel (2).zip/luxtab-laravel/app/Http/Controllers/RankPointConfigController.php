<?php

namespace App\Http\Controllers;

use App\Models\Event;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

/**
 * Ch.4.4.1: the "configured conversion table" a rank_based event uses
 * to turn its Level-2 rank into a Level-3 point value. Saved as a full
 * replace rather than incremental edits since the table is small and
 * always edited as a set (1st = X, 2nd = Y, ...).
 */
class RankPointConfigController extends Controller
{
    public function update(Request $request, Event $event): RedirectResponse
    {
        $this->authorize('update', $event);

        $validated = $request->validate([
            'ranks' => ['required', 'array', 'min:1'],
            'ranks.*.rank_position' => ['required', 'integer', 'min:1'],
            'ranks.*.points' => ['required', 'numeric', 'min:0'],
        ]);

        $event->rankPointConfigs()->delete();
        foreach ($validated['ranks'] as $row) {
            $event->rankPointConfigs()->create($row);
        }

        return back()->with('success', 'Rank-to-points table updated.');
    }
}
