<?php

namespace App\Http\Controllers;

use App\Enums\Role;
use App\Models\Event;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;

class DashboardController extends Controller
{
    public function index(Request $request): Response
    {
        $user = $request->user();

        $eventsQuery = match ($user->role) {
            Role::Organizer => Event::where('organizer_id', $user->user_id),
            Role::Tabulator => Event::where('tabulator_id', $user->user_id)
                ->orWhereHas('tabulators', fn ($q) => $q->where('users.user_id', $user->user_id)),
            Role::TournamentManager => Event::whereHas('tournamentManagers', fn ($q) => $q->where('users.user_id', $user->user_id)),
            Role::Judge => Event::whereHas('judges', fn ($q) => $q->where('user_id', $user->user_id)),
            default => Event::query(),
        };

        $events = $eventsQuery->with(['category', 'season'])
            ->orderByDesc('schedule')
            ->limit(10)
            ->get()
            ->map(fn (Event $e) => [
                'event_id' => $e->event_id,
                'name' => $e->name,
                'status' => $e->status,
                'program' => $e->category->program,
                'category' => $e->category->name,
                'schedule' => $e->schedule?->toIso8601String(),
                'is_finalized' => $e->is_finalized,
                'scoring_type' => $e->scoring_type,
            ]);

        return Inertia::render('Dashboard/Index', [
            'events' => $events,
            'stats' => [
                'total_events' => (clone $eventsQuery)->count(),
                'finalized' => (clone $eventsQuery)->where('is_finalized', true)->count(),
                'ongoing' => (clone $eventsQuery)->where('status', 'ongoing')->count(),
            ],
        ]);
    }
}
