<?php

namespace App\Http\Controllers;

use App\Models\Event;
use App\Services\ScoreComputationService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;

class TabulationController extends Controller
{
    public function __construct(private ScoreComputationService $scores) {}

    public function show(Request $request, Event $event): Response
    {
        if (! $request->user()->canTabulate($event)) {
            abort(403);
        }

        $event->load(['participants.institute', 'judges', 'deductions', 'category', 'rankPointConfigs']);

        $standings = $event->isCriteriaBased() || $event->isByRound()
            ? $event->participants->map(fn ($p) => [
                'institute_id' => $p->institute_id,
                'institute' => $p->institute?->name,
                'score' => $this->scores->eventScoreForParticipant($event, $p),
            ])->sortByDesc('score')->values()
            : collect();

        $judgesStatus = $event->judges->map(fn ($j) => [
            'id' => $j->id,
            'name' => $j->name,
            'is_guest' => $j->isGuest(),
            'has_submitted' => $j->hasSubmitted(),
            'entries_count' => $j->scoreEntries()->count(),
        ]);

        return Inertia::render('Tabulation/Show', [
            'event' => $event,
            'standings' => $standings,
            'judgesStatus' => $judgesStatus,
            'allJudgesSubmitted' => $event->isCriteriaBased() ? $judgesStatus->every(fn ($j) => $j['has_submitted']) : true,
        ]);
    }

    public function finalize(Request $request, Event $event): RedirectResponse
    {
        if (! $request->user()->canTabulate($event)) {
            abort(403);
        }

        if ($event->isCriteriaBased()) {
            $unsubmitted = $event->judges()->whereNull('submitted_at')->count();
            if ($unsubmitted > 0) {
                return back()->with('error', "{$unsubmitted} judge(s) haven't submitted their scores yet.");
            }
        }

        $this->scores->finalizeEvent($event, $request->user());

        return redirect()->route('tabulation.show', $event)->with('success', 'Standings finalized.');
    }

    public function reopen(Request $request, Event $event): RedirectResponse
    {
        if (! $request->user()->canTabulate($event)) {
            abort(403);
        }

        $this->scores->unfinalizeEvent($event, $request->user());

        return back()->with('success', 'Event reopened for corrections.');
    }

    public function toggleVisibility(Request $request, Event $event): RedirectResponse
    {
        if (! $request->user()->canTabulate($event)) {
            abort(403);
        }

        $this->scores->setLeaderboardVisibility($event, ! $event->leaderboard_visible, $request->user());

        return back()->with('success', $event->fresh()->leaderboard_visible ? 'Leaderboard shown.' : 'Leaderboard hidden.');
    }
}
