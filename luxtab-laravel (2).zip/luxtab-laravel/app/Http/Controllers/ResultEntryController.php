<?php

namespace App\Http\Controllers;

use App\Models\Event;
use App\Models\ResultEntry;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

/**
 * For scoring_type = by_round events: the Tabulator enters each
 * participant's result directly (Use Case "Manage Tabulation" ->
 * <<include>> Enter Overall Event Results), rather than judges scoring
 * per criterion.
 */
class ResultEntryController extends Controller
{
    public function update(Request $request, Event $event): RedirectResponse
    {
        if (! $request->user()->canTabulate($event)) {
            abort(403);
        }

        if ($event->is_finalized) {
            return back()->with('error', 'Reopen this event before editing results.');
        }

        $validated = $request->validate([
            'results' => ['required', 'array'],
            'results.*.participant_id' => ['required', 'exists:participants,participant_id'],
            'results.*.overall_score' => ['required', 'numeric'],
            'results.*.score_text' => ['nullable', 'string', 'max:255'],
        ]);

        foreach ($validated['results'] as $row) {
            ResultEntry::updateOrCreate(
                ['event_id' => $event->event_id, 'participant_id' => $row['participant_id']],
                [
                    'tabulator_id' => $request->user()->user_id,
                    'overall_score' => $row['overall_score'],
                    'score_text' => $row['score_text'] ?? null,
                    'entered_at' => now(),
                ]
            );
        }

        return back()->with('success', 'Results saved.');
    }
}
