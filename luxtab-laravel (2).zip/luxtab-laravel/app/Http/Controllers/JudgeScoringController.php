<?php

namespace App\Http\Controllers;

use App\Enums\Role;
use App\Models\Event;
use App\Models\Judge;
use App\Models\JudgeScoreEntry;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;
use Inertia\Inertia;
use Inertia\Response;

/**
 * Use Case "Enter Judge Scores", extends: <<include>> Validate Score
 * Range, <<extend>> Warn: Score Out of Range. Figure 11's flowchart and
 * the Architecture diagram's "Concurrency Management: optimistic
 * locking" both apply here — `signature` is a hash of the judge's known
 * score state at page-load time, echoed back on save and compared
 * server-side so a second concurrent save (e.g. the same judge in two
 * browser tabs) can't silently clobber the first.
 */
class JudgeScoringController extends Controller
{
    public function show(Request $request, Event $event, Judge $judge): Response
    {
        $this->authorizeAccess($request, $event, $judge);

        $event->load(['scoringCriteria', 'participants.institute']);
        $entries = JudgeScoreEntry::where('judge_id', $judge->id)->get()
            ->groupBy('participant_id')
            ->map(fn ($rows) => $rows->keyBy('criterion_id'));

        return Inertia::render('Judge/Scoring', [
            'event' => $event,
            'judge' => $judge,
            'criteria' => $event->scoringCriteria,
            'participants' => $event->participants,
            'entries' => $entries,
            'signature' => $this->computeSignature($judge),
            'isLocked' => $judge->hasSubmitted(),
        ]);
    }

    public function store(Request $request, Event $event, Judge $judge): RedirectResponse
    {
        $this->authorizeAccess($request, $event, $judge);

        if ($judge->hasSubmitted()) {
            return back()->with('error', 'These scores were already submitted. Ask the Tabulator to reopen them first.');
        }

        $validated = $request->validate([
            'signature' => ['required', 'string'],
            'scores' => ['required', 'array'],
            'scores.*.participant_id' => ['required', 'exists:participants,participant_id'],
            'scores.*.criterion_id' => ['required', 'exists:scoring_criteria,criterion_id'],
            'scores.*.raw_score' => ['required', 'numeric', 'min:0'],
        ]);

        if ($validated['signature'] !== $this->computeSignature($judge)) {
            throw ValidationException::withMessages([
                'signature' => 'Your scoring session is out of date (scores changed elsewhere). Please reload before saving.',
            ]);
        }

        $criteriaMax = $event->allScoringCriteria()->pluck('max_score', 'criterion_id');

        foreach ($validated['scores'] as $row) {
            $max = (float) ($criteriaMax[$row['criterion_id']] ?? 0);

            if ($row['raw_score'] > $max) {
                throw ValidationException::withMessages([
                    'scores' => "Score {$row['raw_score']} exceeds this criterion's maximum of {$max}.",
                ]);
            }
        }

        DB::transaction(function () use ($validated, $judge, $event) {
            foreach ($validated['scores'] as $row) {
                JudgeScoreEntry::updateOrCreate(
                    ['judge_id' => $judge->id, 'participant_id' => $row['participant_id'], 'criterion_id' => $row['criterion_id']],
                    [
                        'event_id' => $event->event_id,
                        'raw_score' => $row['raw_score'],
                        'weighted_score' => $row['raw_score'], // criterion-allocated model: no separate weighting step
                        'signature' => null,
                        'submitted_at' => now(),
                    ]
                );
            }
        });

        return back()->with('success', 'Scores saved.');
    }

    public function submit(Request $request, Event $event, Judge $judge): RedirectResponse
    {
        $this->authorizeAccess($request, $event, $judge);

        $expectedCount = $event->allScoringCriteria()->count() * $event->participants()->count();
        $actualCount = JudgeScoreEntry::where('judge_id', $judge->id)->count();

        if ($actualCount < $expectedCount) {
            return back()->with('error', 'Enter a score for every participant and criterion before submitting.');
        }

        $judge->update(['submitted_at' => now()]);

        return back()->with('success', 'Scores submitted and locked.');
    }

    /** Tabulator-only: reopen a judge's submission so a correction can be made. */
    public function reopen(Request $request, Event $event, Judge $judge): RedirectResponse
    {
        if (! $request->user()->canTabulate($event)) {
            abort(403);
        }

        $judge->update(['submitted_at' => null]);

        return back()->with('success', 'Judge scoring reopened for corrections.');
    }

    private function authorizeAccess(Request $request, Event $event, Judge $judge): void
    {
        $user = $request->user();

        // A judge may only score their own panel seat; a Tabulator may
        // enter on behalf of a guest judge (no login) for events they tabulate.
        $isSelf = $user->hasRole(Role::Judge) && $judge->user_id === $user->user_id;
        $isTabulatorOnBehalfOfGuest = $judge->isGuest() && $user->canTabulate($event);

        if (! $isSelf && ! $isTabulatorOnBehalfOfGuest) {
            abort(403, 'You cannot access this scoring sheet.');
        }

        if ($judge->event_id !== $event->event_id) {
            abort(404);
        }
    }

    private function computeSignature(Judge $judge): string
    {
        $state = JudgeScoreEntry::where('judge_id', $judge->id)
            ->orderBy('participant_id')->orderBy('criterion_id')
            ->get(['participant_id', 'criterion_id', 'raw_score'])
            ->map(fn ($e) => "{$e->participant_id}:{$e->criterion_id}:{$e->raw_score}")
            ->implode('|');

        return hash('sha256', $judge->id.'::'.$state);
    }
}
