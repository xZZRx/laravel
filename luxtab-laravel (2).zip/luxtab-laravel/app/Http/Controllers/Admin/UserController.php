<?php

namespace App\Http\Controllers\Admin;

use App\Enums\Role;
use App\Http\Controllers\Controller;
use App\Models\AuditLog;
use App\Models\Institute;
use App\Models\User;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Inertia\Inertia;
use Inertia\Response;

/**
 * Use Case "Manage User Accounts" — Admin-only per the thesis ("Admin
 * manages user accounts and system access", Figure 17 Layer 1). Admin
 * intentionally has no event-level routes anywhere else in this app.
 */
class UserController extends Controller
{
    public function index(Request $request): Response
    {
        $users = User::with('institute')
            ->when($request->string('role')->isNotEmpty(), fn ($q) => $q->where('role', $request->string('role')))
            ->when($request->string('search')->isNotEmpty(), fn ($q) => $q->where(fn ($q2) => $q2
                ->where('name', 'like', '%'.$request->string('search').'%')
                ->orWhere('username', 'like', '%'.$request->string('search').'%')
                ->orWhere('email', 'like', '%'.$request->string('search').'%')
            ))
            ->orderBy('name')
            ->paginate(20)
            ->withQueryString();

        return Inertia::render('Admin/Users/Index', [
            'users' => $users,
            'roles' => Role::values(),
            'filters' => $request->only(['role', 'search']),
        ]);
    }

    public function create(): Response
    {
        return Inertia::render('Admin/Users/Create', [
            'roles' => Role::values(),
            'institutes' => Institute::orderBy('sort_order')->get(),
        ]);
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $this->validated($request);
        $validated['password'] = $validated['password'] ?? \Illuminate\Support\Str::random(12);

        $user = User::create($validated);

        AuditLog::record($request->user()->user_id, 'user.created', 'User', $user->user_id, new: ['username' => $user->username, 'role' => $user->role->value]);

        return redirect()->route('admin.users.index')->with('success', "Account created for {$user->name}.");
    }

    public function update(Request $request, User $user): RedirectResponse
    {
        $validated = $this->validated($request, $user);
        if (empty($validated['password'])) {
            unset($validated['password']);
        }

        $old = $user->only(['name', 'username', 'email', 'role', 'is_active']);
        $user->update($validated);

        AuditLog::record($request->user()->user_id, 'user.updated', 'User', $user->user_id, old: $old, new: $user->only(['name', 'username', 'email', 'role', 'is_active']));

        return back()->with('success', 'Account updated.');
    }

    public function destroy(Request $request, User $user): RedirectResponse
    {
        if ($user->user_id === $request->user()->user_id) {
            return back()->with('error', 'You cannot deactivate your own account.');
        }

        $user->update(['is_active' => false]);

        AuditLog::record($request->user()->user_id, 'user.deactivated', 'User', $user->user_id);

        return back()->with('success', 'Account deactivated.');
    }

    private function validated(Request $request, ?User $user = null): array
    {
        return $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'username' => ['required', 'string', 'max:255', Rule::unique('users', 'username')->ignore($user?->user_id, 'user_id')],
            'email' => ['required', 'email', 'max:255', Rule::unique('users', 'email')->ignore($user?->user_id, 'user_id')],
            'role' => ['required', Rule::in(Role::values())],
            'institute_id' => ['nullable', 'exists:institutes,id'],
            'is_active' => ['boolean'],
            'password' => [$user ? 'nullable' : 'required', 'string', 'min:8'],
        ]);
    }
}
