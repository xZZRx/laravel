<?php

namespace App\Http\Controllers;

use App\Enums\Role;
use App\Http\Requests\StoreEventRequest;
use App\Models\Event;
use App\Models\EventCategory;
use App\Models\Institute;
use App\Models\Season;
use App\Models\User;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Inertia\Inertia;
use Inertia\Response;

class EventController extends Controller
{
    public function index(Request $request): Response
    {
        $this->authorize('viewAny', Event::class);

        $events = Event::query()
            ->with(['category', 'season', 'organizer'])
            ->when($request->string('program')->isNotEmpty(), fn ($q) => $q->whereHas(
                'category', fn ($c) => $c->where('program', $request->string('program'))
            ))
            ->when($request->string('status')->isNotEmpty(), fn ($q) => $q->where('status', $request->string('status')))
            ->orderByDesc('schedule')
            ->paginate(15)
            ->withQueryString();

        return Inertia::render('Events/Index', [
            'events' => $events,
            'filters' => $request->only(['program', 'status']),
        ]);
    }

    public function create(): Response
    {
        $this->authorize('create', Event::class);

        return Inertia::render('Events/Create', [
            'seasons' => Season::active()->get(),
            'categories' => EventCategory::orderBy('program')->orderBy('sort_order')->get(),
            'tabulators' => User::where('role', Role::Tabulator)->orderBy('name')->get(['user_id', 'name']),
        ]);
    }

    public function store(StoreEventRequest $request): RedirectResponse
    {
        $validated = $request->validated();
        $validated['slug'] = Str::slug($validated['name']).'-'.Str::random(4);
        $validated['organizer_id'] = $request->user()->user_id;
        $validated['status'] = 'draft';

        $event = Event::create($validated);

        return redirect()->route('events.edit', $event)
            ->with('success', 'Event created. Continue configuring scoring criteria, participants, and staff below.');
    }

    public function show(Event $event): Response
    {
        $this->authorize('view', $event);

        $event->load([
            'category', 'season', 'organizer', 'tabulator',
            'scoringCriteria.children', 'participants.institute',
            'judges.user', 'rankPointConfigs', 'tournament.matches',
        ]);

        return Inertia::render('Events/Show', [
            'event' => $event,
            'can' => [
                'update' => request()->user()?->can('update', $event),
                'tabulate' => request()->user()?->can('tabulate', $event),
                'score' => request()->user()?->can('score', $event),
            ],
        ]);
    }

    public function edit(Event $event): Response
    {
        $this->authorize('update', $event);

        $event->load([
            'scoringCriteria.children', 'participants.institute', 'judges.user',
            'rankPointConfigs', 'tabulators', 'tournamentManagers',
        ]);

        return Inertia::render('Events/Edit', [
            'event' => $event,
            'institutes' => Institute::active()->orderBy('sort_order')->get(),
            'tabulators' => User::where('role', Role::Tabulator)->get(['user_id', 'name']),
            'tournamentManagers' => User::where('role', Role::TournamentManager)->get(['user_id', 'name']),
            'judgeUsers' => User::where('role', Role::Judge)->get(['user_id', 'name']),
            'criteriaWeightTotal' => $event->criteriaWeightTotal(),
        ]);
    }

    public function update(StoreEventRequest $request, Event $event): RedirectResponse
    {
        $this->authorize('update', $event);

        $event->update($request->validated());

        return back()->with('success', 'Event details updated.');
    }

    public function destroy(Event $event): RedirectResponse
    {
        $this->authorize('delete', $event);

        $event->delete();

        return redirect()->route('events.index')->with('success', 'Event deleted.');
    }
}
