<?php

namespace App\Http\Controllers;

use App\Models\Event;
use App\Models\ScoringCriterion;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

/**
 * Use Case "Set Scoring Method" / Module 2 "assign weights to each
 * criterion". Because max_score IS the weight under the criterion-
 * allocated model (Ch.4.4.1), the only validation that matters here is
 * that top-level criteria sum to 100 — this is what backs the "Weights
 * Must Sum to 100%" warning from Use Case 3.
 */
class ScoringCriterionController extends Controller
{
    public function store(Request $request, Event $event): RedirectResponse
    {
        $this->authorize('update', $event);

        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'description' => ['nullable', 'string'],
            'max_score' => ['required', 'numeric', 'min:0.01', 'max:100'],
            'parent_id' => ['nullable', 'exists:scoring_criteria,criterion_id'],
        ]);

        $event->allScoringCriteria()->create([
            ...$validated,
            'sort_order' => $event->allScoringCriteria()->count(),
        ]);

        return back()->with('success', 'Criterion added.');
    }

    public function update(Request $request, Event $event, ScoringCriterion $criterion): RedirectResponse
    {
        $this->authorize('update', $event);

        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'description' => ['nullable', 'string'],
            'max_score' => ['required', 'numeric', 'min:0.01', 'max:100'],
        ]);

        $criterion->update($validated);

        return back()->with('success', 'Criterion updated.');
    }

    public function destroy(Event $event, ScoringCriterion $criterion): RedirectResponse
    {
        $this->authorize('update', $event);

        if ($event->judgeScoreEntries()->where('criterion_id', $criterion->criterion_id)->exists()) {
            return back()->with('error', 'Cannot remove a criterion that already has scores entered against it.');
        }

        $criterion->delete();

        return back()->with('success', 'Criterion removed.');
    }
}
