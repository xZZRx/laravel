<?php

namespace App\Http\Controllers;

use App\Models\AuditLog;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;

class AuditLogController extends Controller
{
    public function index(Request $request): Response
    {
        $logs = AuditLog::with('user')
            ->when($request->string('action')->isNotEmpty(), fn ($q) => $q->where('action', 'like', $request->string('action').'%'))
            ->when($request->string('target_type')->isNotEmpty(), fn ($q) => $q->where('target_type', $request->string('target_type')))
            ->orderByDesc('performed_at')
            ->paginate(30)
            ->withQueryString();

        return Inertia::render('Admin/AuditLog', [
            'logs' => $logs,
            'filters' => $request->only(['action', 'target_type']),
        ]);
    }
}
