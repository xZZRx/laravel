<?php

namespace App\Http\Controllers;

use App\Models\Event;
use App\Services\BracketGenerationService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Inertia\Inertia;
use Inertia\Response;

class TournamentController extends Controller
{
    public function __construct(private BracketGenerationService $brackets) {}

    public function show(Event $event): Response
    {
        $event->load(['tournament.matches.participantA', 'tournament.matches.participantB', 'tournament.matches.winner', 'participants.institute']);

        return Inertia::render('Tournaments/Show', [
            'event' => $event,
        ]);
    }

    public function store(Request $request, Event $event): RedirectResponse
    {
        if (! $request->user()->canManageTournament($event) && ! $request->user()->can('update', $event)) {
            abort(403);
        }

        $validated = $request->validate([
            'format' => ['required', Rule::in(['single_elimination', 'double_elimination', 'round_robin'])],
            'seeded' => ['boolean'],
        ]);

        $participants = $event->participants()->with('institute')->get();
        if ($participants->count() < 2) {
            return back()->with('error', 'At least 2 participants are required to generate a bracket.');
        }

        $this->brackets->generate($event, $validated['format'], $participants, $request->user(), $validated['seeded'] ?? false);

        return redirect()->route('tournaments.show', $event)->with('success', 'Bracket generated.');
    }
}
