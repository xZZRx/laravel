<?php

namespace App\Http\Controllers;

use App\Models\Event;
use App\Models\GameMatch;
use App\Services\BracketGenerationService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

/**
 * Use Case "Manage Match Schedules" (Tournament Manager) and the result-
 * recording half of Figure 13's flowchart. `winner_id` is required for
 * a manual result but is also set automatically for byes at generation
 * time (see BracketGenerationService).
 */
class GameMatchController extends Controller
{
    public function __construct(private BracketGenerationService $brackets) {}

    public function recordResult(Request $request, Event $event, GameMatch $match): RedirectResponse
    {
        $this->authorizeMatchAccess($request, $event);

        $validated = $request->validate([
            'winner_id' => ['required', Rule::in([$match->participant_a_id, $match->participant_b_id])],
            'score_a' => ['nullable', 'numeric'],
            'score_b' => ['nullable', 'numeric'],
            'score_a_text' => ['nullable', 'string', 'max:100'],
            'score_b_text' => ['nullable', 'string', 'max:100'],
        ]);

        $this->brackets->recordResult(
            $match,
            (int) $validated['winner_id'],
            isset($validated['score_a']) ? (float) $validated['score_a'] : null,
            isset($validated['score_b']) ? (float) $validated['score_b'] : null,
            $validated['score_a_text'] ?? null,
            $validated['score_b_text'] ?? null,
        );

        return back()->with('success', 'Match result recorded.');
    }

    public function reschedule(Request $request, Event $event, GameMatch $match): RedirectResponse
    {
        $this->authorizeMatchAccess($request, $event);

        $validated = $request->validate([
            'match_date' => ['required', 'date'],
            'venue' => ['nullable', 'string', 'max:255'],
            'reason' => ['required', 'string', 'max:1000'],
        ]);

        $match->update([
            'rescheduled_from' => $match->match_date,
            'reschedule_reason' => $validated['reason'],
            'match_date' => $validated['match_date'],
            'venue' => $validated['venue'] ?? $match->venue,
        ]);

        return back()->with('success', 'Match rescheduled.');
    }

    public function setStatus(Request $request, Event $event, GameMatch $match): RedirectResponse
    {
        $this->authorizeMatchAccess($request, $event);

        $validated = $request->validate([
            'status' => ['required', Rule::in([GameMatch::STATUS_SCHEDULED, GameMatch::STATUS_ONGOING, GameMatch::STATUS_COMPLETED])],
        ]);

        $match->update(['status' => $validated['status']]);

        return back()->with('success', 'Match status updated.');
    }

    private function authorizeMatchAccess(Request $request, Event $event): void
    {
        $user = $request->user();
        if (! $user->canManageTournament($event) && ! $user->can('update', $event) && ! $user->canTabulate($event)) {
            abort(403);
        }
    }
}
