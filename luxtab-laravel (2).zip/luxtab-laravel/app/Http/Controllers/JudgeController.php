<?php

namespace App\Http\Controllers;

use App\Models\Event;
use App\Models\Judge;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

class JudgeController extends Controller
{
    /**
     * Adds a judge to the panel — either a registered `judge` user
     * (user_id set) or a guest judge with no account (name/title only,
     * scored on their behalf by the Tabulator).
     */
    public function store(Request $request, Event $event): RedirectResponse
    {
        $this->authorize('update', $event);

        $validated = $request->validate([
            'user_id' => ['nullable', 'exists:users,user_id'],
            'name' => ['required_without:user_id', 'nullable', 'string', 'max:255'],
            'title' => ['nullable', 'string', 'max:255'],
        ]);

        if (! empty($validated['user_id'])) {
            $user = \App\Models\User::findOrFail($validated['user_id']);
            $validated['name'] = $user->name;
        }

        $event->judges()->create([
            ...$validated,
            'sort_order' => $event->judges()->count(),
        ]);

        return back()->with('success', 'Judge added to panel.');
    }

    public function destroy(Event $event, Judge $judge): RedirectResponse
    {
        $this->authorize('update', $event);

        if ($judge->scoreEntries()->exists()) {
            return back()->with('error', 'Cannot remove a judge who has already entered scores.');
        }

        $judge->delete();

        return back()->with('success', 'Judge removed from panel.');
    }
}
