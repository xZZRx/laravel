<?php

namespace App\Http\Controllers;

use App\Models\Event;
use App\Models\Institute;
use App\Models\Participant;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

class ParticipantController extends Controller
{
    /** Bulk-sync which institutes are competing in this event (wizard step 3). */
    public function sync(Request $request, Event $event): RedirectResponse
    {
        $this->authorize('update', $event);

        $validated = $request->validate([
            'institute_ids' => ['required', 'array', 'min:1'],
            'institute_ids.*' => ['exists:institutes,id'],
        ]);

        $existing = $event->participants()->pluck('institute_id')->all();
        $toAdd = array_diff($validated['institute_ids'], $existing);
        $toRemove = array_diff($existing, $validated['institute_ids']);

        foreach ($toAdd as $instituteId) {
            $institute = Institute::find($instituteId);
            $event->participants()->create(['institute_id' => $instituteId, 'name' => $institute->name]);
        }

        if ($toRemove) {
            $removable = $event->participants()->whereIn('institute_id', $toRemove);
            // Don't silently orphan scores already entered against a participant being removed.
            $removable->whereDoesntHave('judgeScoreEntries')->whereDoesntHave('resultEntry')->delete();
        }

        return back()->with('success', 'Participating institutes updated.');
    }

    public function destroy(Event $event, Participant $participant): RedirectResponse
    {
        $this->authorize('update', $event);

        if ($participant->judgeScoreEntries()->exists() || $participant->resultEntry()->exists()) {
            return back()->with('error', 'Cannot remove a participant that already has scores entered.');
        }

        $participant->delete();

        return back()->with('success', 'Participant removed.');
    }
}
