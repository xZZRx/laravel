<?php

namespace App\Http\Controllers;

use App\Models\Event;
use App\Models\EventCategory;
use App\Models\LeaderboardSnapshot;
use App\Models\Season;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;

/**
 * Use Case "View Live Leaderboard": <<include>> Filter by Event
 * Category, <<extend>> Show: Results Not Yet Available. Public-facing —
 * no role check — but every query is scoped to `is_visible`/
 * `leaderboard_visible` so nothing appears here before a Tabulator
 * confirms it (Use Case "Toggle Leaderboard Visibility").
 */
class LeaderboardController extends Controller
{
    public function index(Request $request): Response
    {
        $program = $request->string('program')->value() ?: 'lmc';
        $season = Season::program($program)->active()->first();

        $overall = $season
            ? LeaderboardSnapshot::overall()
                ->where('season_id', $season->id)
                ->visible()
                ->with('institute')
                ->orderBy('rank')
                ->get()
            : collect();

        $categories = EventCategory::program($program)->orderBy('sort_order')->get();

        $eventsQuery = $season ? $season->events()->where('leaderboard_visible', true) : Event::whereRaw('1=0');
        if ($request->filled('category_id')) {
            $eventsQuery->where('event_category_id', $request->integer('category_id'));
        }

        $events = $eventsQuery->with('category')->orderByDesc('schedule')->get()->map(fn (Event $e) => [
            'event_id' => $e->event_id,
            'name' => $e->name,
            'category' => $e->category->name,
            'schedule' => $e->schedule?->toIso8601String(),
        ]);

        return Inertia::render('Leaderboard/Index', [
            'program' => $program,
            'season' => $season,
            'overall' => $overall,
            'categories' => $categories,
            'events' => $events,
            'filters' => $request->only('category_id'),
            'seasonAvailable' => (bool) $season,
        ]);
    }

    public function show(Event $event): Response
    {
        if (! $event->leaderboard_visible) {
            return Inertia::render('Leaderboard/NotAvailable', ['eventName' => $event->name]);
        }

        $snapshots = LeaderboardSnapshot::forEvent($event->event_id)
            ->visible()
            ->with('institute')
            ->orderBy('rank')
            ->get();

        return Inertia::render('Leaderboard/EventShow', [
            'event' => $event->load('category', 'season'),
            'standings' => $snapshots,
        ]);
    }

    /** Auto-refreshing big-screen display for the venue TV, per the previous system's leaderboard_tv page. */
    public function tv(Request $request): Response
    {
        return $this->index($request);
    }
}
