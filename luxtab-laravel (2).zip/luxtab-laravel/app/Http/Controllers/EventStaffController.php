<?php

namespace App\Http\Controllers;

use App\Models\Event;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

/**
 * Module 2, key feature 5: "Assignment of a designated Tabulator,
 * Judge(s), and Tournament Manager to each specific event." The single
 * designated Tabulator lives on events.tabulator_id (edited via
 * EventController::update); this controller manages the *additional*
 * Tabulators/TMs pivot, kept from the previous build per documented
 * adviser feedback that one event may need more than one.
 */
class EventStaffController extends Controller
{
    public function syncTabulators(Request $request, Event $event): RedirectResponse
    {
        $this->authorize('update', $event);

        $validated = $request->validate([
            'user_ids' => ['array'],
            'user_ids.*' => ['exists:users,user_id'],
        ]);

        $event->tabulators()->sync($validated['user_ids'] ?? []);

        return back()->with('success', 'Additional Tabulators updated.');
    }

    public function syncTournamentManagers(Request $request, Event $event): RedirectResponse
    {
        $this->authorize('update', $event);

        $validated = $request->validate([
            'user_ids' => ['array'],
            'user_ids.*' => ['exists:users,user_id'],
        ]);

        $event->tournamentManagers()->sync($validated['user_ids'] ?? []);

        return back()->with('success', 'Tournament Managers updated.');
    }
}
