<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StoreEventRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()->hasRole(\App\Enums\Role::Organizer);
    }

    public function rules(): array
    {
        return [
            'season_id' => ['required', 'exists:seasons,id'],
            'event_category_id' => ['required', 'exists:event_categories,id'],
            'name' => ['required', 'string', 'max:255'],
            'description' => ['nullable', 'string'],
            'type' => ['required', Rule::in(['sports', 'academic', 'special'])],
            'participation_type' => ['required', Rule::in(['institute', 'team', 'individual'])],
            'scoring_type' => ['required', Rule::in(['criteria_based', 'by_round'])],
            'scoring_method' => ['required', Rule::in(['rank_based', 'points_based'])],
            'venue' => ['nullable', 'string', 'max:255'],
            'schedule' => ['nullable', 'date'],
            'tabulator_id' => ['nullable', 'exists:users,user_id'],
        ];
    }
}
