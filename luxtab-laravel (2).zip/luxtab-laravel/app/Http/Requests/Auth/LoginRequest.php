<?php

namespace App\Http\Requests\Auth;

use App\Models\User;
use Illuminate\Auth\Events\Lockout;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

/**
 * Use Case 1 "Authenticate (Login)" extends into two distinct warnings
 * (Figure 15): "Warn: Account Not Found" when the identifier doesn't
 * match any user, and "Warn: Invalid Credentials" when it matches but
 * the password doesn't. Both are implemented literally below rather
 * than collapsed into one generic "invalid login" message.
 */
class LoginRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'username' => ['required', 'string'],
            'password' => ['required', 'string'],
        ];
    }

    public function authenticate(): void
    {
        $this->ensureIsNotRateLimited();

        $identifier = $this->string('username')->value();
        $field = str_contains($identifier, '@') ? 'email' : 'username';

        $user = User::where($field, $identifier)->first();

        if (! $user) {
            RateLimiter::hit($this->throttleKey());

            throw ValidationException::withMessages([
                'username' => 'No account was found for that username or email.',
            ]);
        }

        if (! $user->is_active) {
            throw ValidationException::withMessages([
                'username' => 'This account has been deactivated. Contact an Admin.',
            ]);
        }

        if (! Auth::attempt([$field => $identifier, 'password' => $this->string('password')->value()], $this->boolean('remember'))) {
            RateLimiter::hit($this->throttleKey());

            throw ValidationException::withMessages([
                'password' => 'Incorrect password.',
            ]);
        }

        RateLimiter::clear($this->throttleKey());
        $user->forceFill(['last_login_at' => now()])->save();
    }

    public function ensureIsNotRateLimited(): void
    {
        if (! RateLimiter::tooManyAttempts($this->throttleKey(), 5)) {
            return;
        }

        event(new Lockout($this));

        $seconds = RateLimiter::availableIn($this->throttleKey());

        throw ValidationException::withMessages([
            'username' => "Too many login attempts. Try again in {$seconds} seconds.",
        ]);
    }

    public function throttleKey(): string
    {
        return Str::transliterate(Str::lower($this->string('username')).'|'.$this->ip());
    }
}
