<?php

namespace App\Http\Middleware;

use Illuminate\Http\Request;
use Inertia\Middleware;

class HandleInertiaRequests extends Middleware
{
    /**
     * The root Blade template loaded on the first page visit.
     */
    protected $rootView = 'app';

    /**
     * Bust the client-side cache whenever the deployed assets change.
     */
    public function version(Request $request): ?string
    {
        return parent::version($request);
    }

    /**
     * Data shared with every Inertia page. `auth.user` drives the
     * role-aware sidebar/dashboard redirect (Use Case 1); `flash`
     * surfaces one-off success/error banners after redirects.
     */
    public function share(Request $request): array
    {
        return [
            ...parent::share($request),
            'auth' => [
                'user' => $request->user() ? [
                    'user_id' => $request->user()->user_id,
                    'name' => $request->user()->name,
                    'username' => $request->user()->username,
                    'email' => $request->user()->email,
                    'role' => $request->user()->role->value,
                    'role_label' => $request->user()->role->label(),
                    'institute_id' => $request->user()->institute_id,
                    'avatar_path' => $request->user()->avatar_path,
                ] : null,
            ],
            'flash' => [
                'success' => fn () => $request->session()->get('success'),
                'error' => fn () => $request->session()->get('error'),
            ],
        ];
    }
}
