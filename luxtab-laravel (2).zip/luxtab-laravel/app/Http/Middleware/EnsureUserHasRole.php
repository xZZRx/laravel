<?php

namespace App\Http\Middleware;

use App\Enums\Role;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Route-level RBAC: `->middleware('role:organizer,admin')`. Admin does
 * NOT automatically pass every check — per the thesis, Admin is scoped
 * to user-account management only and has no event-level access, so
 * routes must opt Admin in explicitly where that's actually intended
 * (e.g. never for scoring/tabulation routes).
 */
class EnsureUserHasRole
{
    public function handle(Request $request, Closure $next, string ...$roles): Response
    {
        $user = $request->user();

        if (! $user) {
            return redirect()->route('login');
        }

        $allowed = array_map(fn (string $r) => Role::from($r), $roles);

        if (! $user->hasAnyRole($allowed)) {
            abort(403, 'You do not have access to this page.');
        }

        return $next($request);
    }
}
