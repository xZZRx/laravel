<?php

use App\Http\Controllers\Admin\UserController as AdminUserController;
use App\Http\Controllers\AuditLogController;
use App\Http\Controllers\Auth\AuthenticatedSessionController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\DeductionController;
use App\Http\Controllers\EventController;
use App\Http\Controllers\EventStaffController;
use App\Http\Controllers\GameMatchController;
use App\Http\Controllers\JudgeController;
use App\Http\Controllers\JudgeScoringController;
use App\Http\Controllers\LeaderboardController;
use App\Http\Controllers\ParticipantController;
use App\Http\Controllers\RankPointConfigController;
use App\Http\Controllers\ResultEntryController;
use App\Http\Controllers\ScoringCriterionController;
use App\Http\Controllers\TabulationController;
use App\Http\Controllers\TournamentController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

// Root: mirrors the previous system's index.php — signed-in staff go to
// their dashboard, everyone else (including guests) lands on the
// public leaderboard.
Route::get('/', function () {
    $user = Auth::user();

    return ($user && $user->role->value !== 'viewer')
        ? redirect()->route('dashboard')
        : redirect()->route('leaderboard.index');
})->name('home');

// Public — Use Case "View Live Leaderboard", no login required.
Route::get('/leaderboard', [LeaderboardController::class, 'index'])->name('leaderboard.index');
Route::get('/leaderboard/tv', [LeaderboardController::class, 'tv'])->name('leaderboard.tv');
Route::get('/leaderboard/events/{event}', [LeaderboardController::class, 'show'])->name('leaderboard.event');

// Guest-only auth routes.
Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthenticatedSessionController::class, 'create'])->name('login');
    Route::post('/login', [AuthenticatedSessionController::class, 'store'])->name('login.store');
});

Route::middleware('auth')->group(function () {
    Route::post('/logout', [AuthenticatedSessionController::class, 'destroy'])->name('logout');

    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

    // --- Events (Organizer creates/edits; everyone signed in can view) ---
    Route::get('/events', [EventController::class, 'index'])->name('events.index');
    Route::get('/events/create', [EventController::class, 'create'])->name('events.create');
    Route::post('/events', [EventController::class, 'store'])->name('events.store');
    Route::get('/events/{event}', [EventController::class, 'show'])->name('events.show');
    Route::get('/events/{event}/edit', [EventController::class, 'edit'])->name('events.edit');
    Route::put('/events/{event}', [EventController::class, 'update'])->name('events.update');
    Route::delete('/events/{event}', [EventController::class, 'destroy'])->name('events.destroy');

    // Wizard/config sub-resources (all authorize via EventPolicy::update internally).
    Route::post('/events/{event}/criteria', [ScoringCriterionController::class, 'store'])->name('criteria.store');
    Route::put('/events/{event}/criteria/{criterion}', [ScoringCriterionController::class, 'update'])->name('criteria.update');
    Route::delete('/events/{event}/criteria/{criterion}', [ScoringCriterionController::class, 'destroy'])->name('criteria.destroy');

    Route::put('/events/{event}/participants', [ParticipantController::class, 'sync'])->name('participants.sync');
    Route::delete('/events/{event}/participants/{participant}', [ParticipantController::class, 'destroy'])->name('participants.destroy');

    Route::post('/events/{event}/judges', [JudgeController::class, 'store'])->name('judges.store');
    Route::delete('/events/{event}/judges/{judge}', [JudgeController::class, 'destroy'])->name('judges.destroy');

    Route::put('/events/{event}/tabulators', [EventStaffController::class, 'syncTabulators'])->name('events.tabulators.sync');
    Route::put('/events/{event}/tournament-managers', [EventStaffController::class, 'syncTournamentManagers'])->name('events.tms.sync');

    Route::put('/events/{event}/rank-points', [RankPointConfigController::class, 'update'])->name('rank-points.update');
    Route::put('/events/{event}/results', [ResultEntryController::class, 'update'])->name('results.update');

    // --- Judge Interface (Use Case: Enter Judge Scores) ---
    Route::get('/events/{event}/judges/{judge}/scoring', [JudgeScoringController::class, 'show'])->name('judge-scoring.show');
    Route::post('/events/{event}/judges/{judge}/scoring', [JudgeScoringController::class, 'store'])->name('judge-scoring.store');
    Route::post('/events/{event}/judges/{judge}/submit', [JudgeScoringController::class, 'submit'])->name('judge-scoring.submit');
    Route::post('/events/{event}/judges/{judge}/reopen', [JudgeScoringController::class, 'reopen'])->name('judge-scoring.reopen');

    // --- Deductions (Use Case: Apply Deductions, 3-level) ---
    Route::post('/events/{event}/deductions', [DeductionController::class, 'store'])->name('deductions.store');
    Route::delete('/deductions/{deduction}', [DeductionController::class, 'destroy'])->name('deductions.destroy');
    Route::post('/seasons/{season}/deductions', [DeductionController::class, 'storeOverall'])->name('deductions.overall.store');

    // --- Tabulation (Use Cases: Finalize Standings, Toggle Leaderboard Visibility) ---
    Route::get('/events/{event}/tabulation', [TabulationController::class, 'show'])->name('tabulation.show');
    Route::post('/events/{event}/tabulation/finalize', [TabulationController::class, 'finalize'])->name('tabulation.finalize');
    Route::post('/events/{event}/tabulation/reopen', [TabulationController::class, 'reopen'])->name('tabulation.reopen');
    Route::post('/events/{event}/tabulation/toggle-visibility', [TabulationController::class, 'toggleVisibility'])->name('tabulation.toggle-visibility');

    // --- Tournaments / Brackets (Use Cases: Create Tournament Brackets, Manage Match Schedules) ---
    Route::get('/events/{event}/tournament', [TournamentController::class, 'show'])->name('tournaments.show');
    Route::post('/events/{event}/tournament', [TournamentController::class, 'store'])->name('tournaments.store');
    Route::post('/events/{event}/matches/{match}/result', [GameMatchController::class, 'recordResult'])->name('matches.result');
    Route::post('/events/{event}/matches/{match}/reschedule', [GameMatchController::class, 'reschedule'])->name('matches.reschedule');
    Route::post('/events/{event}/matches/{match}/status', [GameMatchController::class, 'setStatus'])->name('matches.status');

    // --- Admin only (Use Case: Manage User Accounts) ---
    Route::middleware('role:admin')->prefix('admin')->name('admin.')->group(function () {
        Route::get('/users', [AdminUserController::class, 'index'])->name('users.index');
        Route::get('/users/create', [AdminUserController::class, 'create'])->name('users.create');
        Route::post('/users', [AdminUserController::class, 'store'])->name('users.store');
        Route::put('/users/{user}', [AdminUserController::class, 'update'])->name('users.update');
        Route::delete('/users/{user}', [AdminUserController::class, 'destroy'])->name('users.destroy');
        Route::get('/audit-log', [AuditLogController::class, 'index'])->name('audit-log');
    });
});
