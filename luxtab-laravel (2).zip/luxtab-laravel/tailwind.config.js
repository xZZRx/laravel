import forms from '@tailwindcss/forms';

/** @type {import('tailwindcss').Config} */
export default {
    content: [
        './resources/views/**/*.blade.php',
        './resources/js/**/*.jsx',
    ],
    theme: {
        extend: {
            fontFamily: {
                display: ['"Playfair Display"', 'Georgia', 'serif'],
                sans: ['"Outfit"', '"Segoe UI"', 'system-ui', 'sans-serif'],
                mono: ['"DM Mono"', 'Consolas', 'monospace'],
            },
        },
    },
    // The branded palette (green/fire/gold, dark-mode aware) lives in
    // resources/css/app.css as CSS custom properties, ported from the
    // original PHP build's design system — see the `.btn`, `.card`,
    // `.badge-*`, etc. classes there. Tailwind utilities here are used
    // for layout/spacing/flex/grid, not for brand color.
    plugins: [forms],
};
