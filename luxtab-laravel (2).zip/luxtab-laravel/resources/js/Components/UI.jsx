export function Card({ children, className = '', header = null }) {
    return (
        <div className={`card ${className}`}>
            {header}
            {children}
        </div>
    );
}

export function CardHeader({ title, subtitle, right = null, icon = null }) {
    return (
        <div className="card-header">
            <div>
                <div className="card-title">{icon && <i className={icon} />} {title}</div>
                {subtitle && <div className="card-subtitle">{subtitle}</div>}
            </div>
            {right}
        </div>
    );
}

export function Button({ children, variant = 'primary', size, className = '', icon, ...props }) {
    const variantClass = {
        primary: 'btn-primary', secondary: 'btn-secondary', ghost: 'btn-ghost', danger: 'btn-danger', fire: 'btn-fire',
    }[variant];
    const sizeClass = size === 'sm' ? 'btn-sm' : size === 'lg' ? 'btn-lg' : '';

    return (
        <button className={`btn ${variantClass} ${sizeClass} ${className}`} {...props}>
            {icon && <i className={icon} />}
            {children}
        </button>
    );
}

export function Label({ children, ...props }) {
    return <label className="form-label" {...props}>{children}</label>;
}

export function TextInput({ error, className = '', ...props }) {
    return <input className={`form-control ${className}`} {...props} />;
}

export function Select({ error, className = '', children, ...props }) {
    return <select className={`form-control ${className}`} {...props}>{children}</select>;
}

export function FieldError({ children }) {
    if (!children) return null;
    return <p className="form-error">{children}</p>;
}

export function Badge({ children, tone = 'closed' }) {
    return <span className={`badge badge-${tone}`}>{children}</span>;
}

export function EmptyState({ icon = 'ri-inbox-line', title, description }) {
    return (
        <div className="empty-state">
            <div className="empty-icon"><i className={icon} /></div>
            <div className="empty-title">{title}</div>
            {description && <p>{description}</p>}
        </div>
    );
}
