import RankMedallion from './RankMedallion';

const RANK_ROW_CLASS = { 1: 'rank-gold', 2: 'rank-silver', 3: 'rank-bronze' };
const MEDAL_CHIP = { 1: ['medal-gold', 'Gold'], 2: ['medal-silver', 'Silver'], 3: ['medal-bronze', 'Bronze'] };

/**
 * Shared standings table — matches assets/css/app.css's
 * .standings-table / .rank-gold/silver/bronze / .medal-chip pattern.
 * Used by the public leaderboard and the Tabulation review screen.
 */
export default function StandingsTable({ rows, scoreLabel = 'Score', emptyMessage = 'No standings yet.' }) {
    if (!rows || rows.length === 0) {
        return <p className="empty-state"><span className="empty-title">{emptyMessage}</span></p>;
    }

    return (
        <div className="table-wrap">
            <table className="standings-table">
                <thead>
                    <tr>
                        <th>Rank</th>
                        <th>Institute</th>
                        <th style={{ textAlign: 'right' }}>{scoreLabel}</th>
                    </tr>
                </thead>
                <tbody>
                    {rows.map((row) => (
                        <tr key={row.key ?? row.rank} className={RANK_ROW_CLASS[row.rank] ?? ''}>
                            <td>
                                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                                    <RankMedallion rank={row.rank} />
                                    {MEDAL_CHIP[row.rank] && (
                                        <span className={`medal-chip ${MEDAL_CHIP[row.rank][0]}`}>{MEDAL_CHIP[row.rank][1]}</span>
                                    )}
                                </div>
                            </td>
                            <td>
                                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                                    {row.colorHex && <span className="inst-color-strip" style={{ background: row.colorHex }} />}
                                    <div className="inst-name-group">
                                        <strong>{row.name}</strong>
                                    </div>
                                </div>
                            </td>
                            <td style={{ textAlign: 'right' }}>
                                <span className="points-cell">{row.score}</span>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
}
