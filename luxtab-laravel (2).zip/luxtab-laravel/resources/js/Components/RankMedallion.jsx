export default function RankMedallion({ rank }) {
    const tier = rank === 1 ? 'gold' : rank === 2 ? 'silver' : rank === 3 ? 'bronze' : 'other';
    return <div className={`rank-medal ${tier}`}>{rank ?? '–'}</div>;
}
