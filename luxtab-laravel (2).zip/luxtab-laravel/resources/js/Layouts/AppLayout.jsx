import { Link, usePage, router } from '@inertiajs/react';
import { useEffect, useState } from 'react';

/**
 * Nav structure mirrors includes/sidebar.php: section grouping, role
 * gating, and icons (Remix Icon classes) all carried over. Trimmed to
 * routes that actually exist in this build — see README for the pages
 * (Reports, LMC Years, Institutes, Settings, Help) still to be added.
 */
function buildNav(role) {
    const nav = [];

    nav.push({ section: null, links: [
        { href: '/leaderboard', icon: 'ri-trophy-line', label: 'Leaderboard' },
    ] });

    if (role) {
        nav.push({ section: null, links: [
            { href: '/dashboard', icon: 'ri-dashboard-line', label: 'Dashboard' },
        ] });
    }

    if (['admin', 'organizer', 'tournament_manager', 'tabulator', 'judge'].includes(role)) {
        nav.push({ section: 'Scoring', links: [
            { href: '/events', icon: 'ri-calendar-event-line', label: 'Events' },
        ] });
    }

    if (role === 'admin') {
        nav.push({ section: 'System', links: [
            { href: '/admin/users', icon: 'ri-team-line', label: 'Users & Roles' },
            { href: '/admin/audit-log', icon: 'ri-shield-check-line', label: 'Audit Log' },
        ] });
    }

    return nav;
}

const ROLE_LABELS = {
    admin: 'Admin', organizer: 'Organizer', tournament_manager: 'Tournament Manager',
    judge: 'Judge', tabulator: 'Tabulator', viewer: 'Viewer',
};

function FlashBanner() {
    const { flash } = usePage().props;
    if (!flash?.success && !flash?.error) return null;

    return (
        <div className="px-7 pt-5 space-y-2">
            {flash.success && <div className="alert alert-success"><i className="ri-checkbox-circle-line" /> {flash.success}</div>}
            {flash.error && <div className="alert alert-error"><i className="ri-error-warning-line" /> {flash.error}</div>}
        </div>
    );
}

export default function AppLayout({ children, title }) {
    const { auth } = usePage().props;
    const [sidebarOpen, setSidebarOpen] = useState(false);
    const [isDark, setIsDark] = useState(false);

    useEffect(() => {
        const saved = localStorage.getItem('luxtab_theme');
        setIsDark(saved === 'dark');
    }, []);

    const toggleDark = () => {
        const next = !isDark;
        setIsDark(next);
        document.documentElement.setAttribute('data-theme', next ? 'dark' : 'light');
        localStorage.setItem('luxtab_theme', next ? 'dark' : 'light');
    };

    const nav = buildNav(auth?.user?.role);
    const currentPath = typeof window !== 'undefined' ? window.location.pathname : '';

    const logout = (e) => {
        e.preventDefault();
        router.post('/logout');
    };

    const initials = (auth?.user?.name ?? '?').split(' ').map((w) => w[0]).slice(0, 2).join('').toUpperCase();

    return (
        <div className="app-wrap">
            <div className={`sidebar-overlay ${sidebarOpen ? 'show' : ''}`} onClick={() => setSidebarOpen(false)} />

            <aside className={`sidebar ${sidebarOpen ? 'open' : ''}`}>
                <div className="sidebar-logo">
                    <div className="sidebar-logo-icon"><i className="ri-trophy-fill" /></div>
                    <div className="sidebar-logo-text">
                        <h1>LuxTab</h1>
                        <span>Score System</span>
                    </div>
                </div>

                <nav className="sidebar-nav">
                    {nav.map((group, gi) => (
                        <div key={gi}>
                            {group.section && <div className="nav-section-label">{group.section}</div>}
                            {group.links.map((item) => (
                                <Link
                                    key={item.href}
                                    href={item.href}
                                    className={`nav-item ${currentPath === item.href ? 'active' : ''}`}
                                >
                                    <span className="nav-icon"><i className={item.icon} /></span>
                                    {item.label}
                                </Link>
                            ))}
                        </div>
                    ))}
                </nav>

                <div className="sidebar-footer">
                    <button className="dark-toggle" type="button" onClick={toggleDark}>
                        <span>{isDark ? '☀️ Light Mode' : '🌙 Dark Mode'}</span>
                        <div className="toggle-track"><div className="toggle-thumb" /></div>
                    </button>

                    {auth?.user ? (
                        <>
                            <div className="user-pill">
                                <div className="user-pill-avatar">{initials}</div>
                                <div className="user-pill-info">
                                    <span className="user-pill-name">{auth.user.name}</span>
                                    <span className="user-pill-role">{ROLE_LABELS[auth.user.role]}</span>
                                </div>
                            </div>
                            <a href="#" onClick={logout} className="nav-item" style={{ color: 'rgba(255,255,255,.55)' }}>
                                <span className="nav-icon"><i className="ri-logout-box-r-line" /></span> Sign Out
                            </a>
                        </>
                    ) : (
                        <Link href="/login" className="nav-item" style={{ background: 'rgba(255,255,255,.12)', color: '#fff', fontWeight: 700 }}>
                            <span className="nav-icon"><i className="ri-login-box-line" /></span> Sign In
                        </Link>
                    )}
                </div>
            </aside>

            <div className="content">
                <div className="topbar">
                    <div className="topbar-left">
                        <button type="button" className="sidebar-toggle" onClick={() => setSidebarOpen(true)}>
                            <i className="ri-menu-line" />
                        </button>
                        <span className="topbar-title">{title}</span>
                    </div>
                    <div className="topbar-right">
                        <div className="status-pill status-online">
                            <div className="status-dot" />
                            <span className="hide-mobile">Online</span>
                        </div>
                    </div>
                </div>

                <FlashBanner />

                <div className="page-body">{children}</div>
            </div>
        </div>
    );
}
