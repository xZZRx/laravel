import { Head, Link, usePage } from '@inertiajs/react';
import AppLayout from '../../Layouts/AppLayout';
import { Card, Badge, EmptyState } from '../../Components/UI';

const STATUS_TONE = { draft: 'draft', ongoing: 'open', completed: 'finalized', cancelled: 'danger', rescheduled: 'warning' };

export default function Dashboard({ events, stats }) {
    const { auth } = usePage().props;
    const hour = new Date().getHours();
    const greeting = hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening';

    return (
        <AppLayout title="Dashboard">
            <Head title="Dashboard" />

            <div className="welcome-banner">
                <div>
                    <h2>{greeting}, {auth?.user?.name?.split(' ')[0]}</h2>
                    <p>Here's what's happening across your events.</p>
                </div>
                <i className="ri-sparkling-2-line" style={{ fontSize: '1.8rem', color: 'var(--accent)' }} />
            </div>

            <div className="stats-grid">
                <div className="stat-card">
                    <div className="stat-icon"><i className="ri-calendar-event-line" /></div>
                    <div className="stat-label">Your Events</div>
                    <div className="stat-value">{stats.total_events}</div>
                </div>
                <div className="stat-card fire">
                    <div className="stat-icon"><i className="ri-flashlight-line" /></div>
                    <div className="stat-label">Ongoing</div>
                    <div className="stat-value">{stats.ongoing}</div>
                </div>
                <div className="stat-card gold">
                    <div className="stat-icon"><i className="ri-checkbox-circle-line" /></div>
                    <div className="stat-label">Finalized</div>
                    <div className="stat-value">{stats.finalized}</div>
                </div>
            </div>

            <div className="section-label">Recent Events</div>
            <Card>
                {events.length === 0 ? (
                    <EmptyState icon="ri-calendar-line" title="No events yet" description="Events you organize, tabulate, or judge will show up here." />
                ) : (
                    <div>
                        {events.map((event) => (
                            <Link
                                key={event.event_id}
                                href={`/events/${event.event_id}`}
                                style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '16px 22px', borderBottom: '1px solid var(--border)' }}
                            >
                                <div>
                                    <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, color: 'var(--text-primary)' }}>{event.name}</div>
                                    <div style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 2 }}>
                                        {event.program?.toUpperCase()} · {event.category} · {event.scoring_type === 'by_round' ? 'By-round' : 'Criteria-based'}
                                    </div>
                                </div>
                                <div style={{ display: 'flex', gap: 6 }}>
                                    {event.is_finalized && <Badge tone="finalized">Finalized</Badge>}
                                    <Badge tone={STATUS_TONE[event.status] ?? 'closed'}>{event.status}</Badge>
                                </div>
                            </Link>
                        ))}
                    </div>
                )}
            </Card>
        </AppLayout>
    );
}
