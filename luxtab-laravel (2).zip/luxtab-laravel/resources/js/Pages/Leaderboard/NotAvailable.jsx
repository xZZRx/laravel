import { Head, Link } from '@inertiajs/react';
import AppLayout from '../../Layouts/AppLayout';
import { EmptyState } from '../../Components/UI';

export default function NotAvailable({ eventName }) {
    return (
        <AppLayout title="Results not available">
            <Head title="Results not available" />
            <EmptyState
                icon="ri-time-line"
                title="Results not yet available"
                description={`${eventName ? `Standings for "${eventName}" haven't` : "This event's standings haven't"} been published yet. Check back once the Tabulator confirms results.`}
            />
            <div style={{ textAlign: 'center', marginTop: 12 }}>
                <Link href="/leaderboard" className="back-link" style={{ justifyContent: 'center' }}><i className="ri-arrow-left-line" /> Back to leaderboard</Link>
            </div>
        </AppLayout>
    );
}
