import { Head, Link } from '@inertiajs/react';
import AppLayout from '../../Layouts/AppLayout';
import StandingsTable from '../../Components/StandingsTable';
import { Card } from '../../Components/UI';

export default function LeaderboardEventShow({ event, standings }) {
    const rows = standings.map((s) => ({ key: s.snapshot_id, rank: s.rank, name: s.institute?.name, colorHex: s.institute?.color_hex, score: Number(s.computed_score).toFixed(2) }));

    return (
        <AppLayout title={event.name}>
            <Head title={event.name} />

            <Link href="/leaderboard" className="back-link"><i className="ri-arrow-left-line" /> All standings</Link>

            <div className="page-header">
                <div>
                    <h1 className="page-title">{event.name}</h1>
                    <p className="page-subtitle">{event.category?.name} · {event.season?.label}</p>
                </div>
            </div>

            <Card>
                <div className="card-pad">
                    <StandingsTable rows={rows} scoreLabel="Event score" emptyMessage="No standings published yet." />
                </div>
            </Card>
        </AppLayout>
    );
}
