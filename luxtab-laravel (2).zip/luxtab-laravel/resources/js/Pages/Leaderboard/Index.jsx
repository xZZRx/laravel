import { Head, Link, router } from '@inertiajs/react';
import AppLayout from '../../Layouts/AppLayout';
import StandingsTable from '../../Components/StandingsTable';
import { Card, EmptyState } from '../../Components/UI';

function Podium({ top3 }) {
    if (top3.length < 3) return null;
    const [first, second, third] = top3;
    const initials = (name) => (name ?? '?').slice(0, 3).toUpperCase();

    return (
        <div className="podium">
            <div className="podium-place podium-2nd">
                <div className="podium-avatar" style={{ background: second.colorHex ?? '#64748B' }}>{initials(second.name)}</div>
                <div className="podium-bar">
                    <span className="podium-code">2nd</span>
                    <span className="podium-score">{second.score}</span>
                </div>
            </div>
            <div className="podium-place podium-1st">
                <div className="podium-avatar" style={{ background: first.colorHex ?? '#F59E0B' }}>{initials(first.name)}</div>
                <div className="podium-bar">
                    <span className="podium-code">1st</span>
                    <span className="podium-score">{first.score}</span>
                </div>
            </div>
            <div className="podium-place podium-3rd">
                <div className="podium-avatar" style={{ background: third.colorHex ?? 'var(--green-600)' }}>{initials(third.name)}</div>
                <div className="podium-bar">
                    <span className="podium-code">3rd</span>
                    <span className="podium-score">{third.score}</span>
                </div>
            </div>
        </div>
    );
}

export default function LeaderboardIndex({ program, season, overall, categories, events, filters, seasonAvailable }) {
    const switchProgram = (p) => router.get('/leaderboard', { program: p }, { preserveState: true });
    const filterCategory = (id) => router.get('/leaderboard', { program, category_id: id || undefined }, { preserveState: true });

    const rows = overall.map((s) => ({ key: s.snapshot_id, rank: s.rank, name: s.institute?.name, colorHex: s.institute?.color_hex, score: Number(s.computed_score).toFixed(2) }));
    const top3 = rows.filter((r) => r.rank <= 3).sort((a, b) => a.rank - b.rank);

    return (
        <AppLayout title="Leaderboard">
            <Head title="Leaderboard" />

            <div className="lb-hero">
                <div className="lb-trophy">🏆</div>
                <div className="lb-year-pill">{season?.label ?? 'No active season'}</div>
                <h1 className="lb-main-title">Overall Standings</h1>
                <p className="lb-subtitle">Live, Tabulator-confirmed results across every finalized event.</p>
            </div>

            <div className="cat-tabs" style={{ justifyContent: 'center', marginBottom: 24 }}>
                <button className={`cat-tab ${program === 'lmc' ? 'active' : ''}`} onClick={() => switchProgram('lmc')}>Luxmundis Cup</button>
                <button className={`cat-tab ${program === 'arso' ? 'active' : ''}`} onClick={() => switchProgram('arso')}>ARSO Festival</button>
            </div>

            {!seasonAvailable ? (
                <EmptyState icon="ri-trophy-line" title="No active season for this program yet" />
            ) : (
                <>
                    <Podium top3={top3} />

                    <Card style={{ marginBottom: 28 }}>
                        <div className="card-pad">
                            <StandingsTable rows={rows} scoreLabel="Overall score" emptyMessage="Results not yet available — standings appear once events are finalized and published." />
                        </div>
                    </Card>

                    <div className="page-header">
                        <div className="page-title" style={{ fontSize: '1.15rem' }}>Published events</div>
                        <div className="category-tabs">
                            <button className={`cat-tab ${!filters.category_id ? 'active' : ''}`} onClick={() => filterCategory('')}>All</button>
                            {categories.map((c) => (
                                <button key={c.id} className={`cat-tab ${String(filters.category_id) === String(c.id) ? 'active' : ''}`} onClick={() => filterCategory(c.id)}>{c.name}</button>
                            ))}
                        </div>
                    </div>

                    <div className="stats-grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))' }}>
                        {events.map((e) => (
                            <Link key={e.event_id} href={`/leaderboard/events/${e.event_id}`} className="card" style={{ padding: '16px 18px', display: 'block' }}>
                                <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, color: 'var(--brand)' }}>{e.name}</div>
                                <div style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 3 }}>{e.category}</div>
                            </Link>
                        ))}
                        {events.length === 0 && <p style={{ color: 'var(--text-muted)', fontSize: 13 }}>No published event results yet.</p>}
                    </div>
                </>
            )}
        </AppLayout>
    );
}
