import { useForm, Head } from '@inertiajs/react';

export default function Login() {
    const { data, setData, post, processing, errors } = useForm({
        username: '',
        password: '',
        remember: false,
    });

    const submit = (e) => {
        e.preventDefault();
        post('/login');
    };

    return (
        <div className="login-wrap">
            <Head title="Sign in" />

            <div className="login-form-side">
                <div className="login-form-inner">
                    <div className="login-logo-mark">
                        <div className="login-logo-icon"><i className="ri-trophy-fill" /></div>
                        <div>
                            <span className="login-brand-name">LuxTab</span>
                            <span className="login-brand-sub">Score System</span>
                        </div>
                    </div>

                    <h1 className="login-heading">Welcome back</h1>
                    <p className="login-subhead">Sign in to manage events, enter scores, and review standings.</p>

                    <form onSubmit={submit}>
                        <div className="form-group">
                            <label className="form-label" htmlFor="username">Username or email</label>
                            <input
                                id="username"
                                type="text"
                                autoFocus
                                autoComplete="username"
                                value={data.username}
                                onChange={(e) => setData('username', e.target.value)}
                                className="form-control"
                            />
                            {errors.username && <p className="form-error">{errors.username}</p>}
                        </div>

                        <div className="form-group">
                            <label className="form-label" htmlFor="password">Password</label>
                            <input
                                id="password"
                                type="password"
                                autoComplete="current-password"
                                value={data.password}
                                onChange={(e) => setData('password', e.target.value)}
                                className="form-control"
                            />
                            {errors.password && <p className="form-error">{errors.password}</p>}
                        </div>

                        <label style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, color: 'var(--text-secondary)', marginBottom: 6 }}>
                            <input
                                type="checkbox"
                                checked={data.remember}
                                onChange={(e) => setData('remember', e.target.checked)}
                            />
                            Keep me signed in
                        </label>

                        <button type="submit" disabled={processing} className="lf-submit">
                            {processing ? 'Signing in…' : <><i className="ri-login-box-line" /> Sign in</>}
                        </button>
                    </form>
                </div>
            </div>

            <div className="login-deco-side">
                <div className="deco-orb deco-orb1" />
                <div className="deco-orb deco-orb2" />
                <div className="deco-orb deco-orb3" />
                <div className="deco-content">
                    <div className="deco-trophy">🏆</div>
                    <h2 className="deco-title">Luxmundis Cup &amp; ARSO Festival</h2>
                    <p className="deco-desc">
                        Automated score tabulation and live standings for TCGC's inter-institute competitions.
                    </p>
                    <div className="deco-features">
                        <div className="deco-feat"><span className="deco-feat-check">✓</span> Three-level, category-weighted scoring</div>
                        <div className="deco-feat"><span className="deco-feat-check">✓</span> Live judge panels &amp; deductions</div>
                        <div className="deco-feat"><span className="deco-feat-check">✓</span> Real-time leaderboard &amp; brackets</div>
                    </div>
                </div>
            </div>
        </div>
    );
}
