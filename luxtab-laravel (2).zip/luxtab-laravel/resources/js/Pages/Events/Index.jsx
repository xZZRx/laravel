import { Head, Link, router } from '@inertiajs/react';
import AppLayout from '../../Layouts/AppLayout';
import { Card, Badge, Button, Select, EmptyState } from '../../Components/UI';

const STATUS_TONE = { draft: 'draft', ongoing: 'open', completed: 'finalized', cancelled: 'danger', rescheduled: 'warning' };

export default function EventsIndex({ events, filters }) {
    const setFilter = (key, value) => {
        router.get('/events', { ...filters, [key]: value || undefined }, { preserveState: true });
    };

    return (
        <AppLayout title="Events">
            <Head title="Events" />

            <div className="page-header">
                <div className="filter-row">
                    <Select value={filters.program ?? ''} onChange={(e) => setFilter('program', e.target.value)} style={{ width: 180 }}>
                        <option value="">All programs</option>
                        <option value="lmc">Luxmundis Cup</option>
                        <option value="arso">ARSO Festival</option>
                    </Select>
                    <Select value={filters.status ?? ''} onChange={(e) => setFilter('status', e.target.value)} style={{ width: 180 }}>
                        <option value="">All statuses</option>
                        <option value="draft">Draft</option>
                        <option value="ongoing">Ongoing</option>
                        <option value="completed">Completed</option>
                        <option value="cancelled">Cancelled</option>
                        <option value="rescheduled">Rescheduled</option>
                    </Select>
                </div>
                <div className="page-header-right">
                    <Link href="/events/create"><Button icon="ri-add-circle-line">New Event</Button></Link>
                </div>
            </div>

            <Card>
                {events.data.length === 0 ? (
                    <EmptyState icon="ri-calendar-line" title="No events match these filters" />
                ) : (
                    <div>
                        {events.data.map((event) => (
                            <Link
                                key={event.event_id}
                                href={`/events/${event.event_id}`}
                                style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '16px 22px', borderBottom: '1px solid var(--border)' }}
                            >
                                <div>
                                    <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, color: 'var(--text-primary)' }}>{event.name}</div>
                                    <div style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 2 }}>
                                        {event.category?.program?.toUpperCase()} · {event.category?.name} · {event.organizer?.name}
                                    </div>
                                </div>
                                <Badge tone={STATUS_TONE[event.status] ?? 'closed'}>{event.status}</Badge>
                            </Link>
                        ))}
                    </div>
                )}
            </Card>

            {events.links && events.links.length > 3 && (
                <div style={{ display: 'flex', gap: 4, marginTop: 16, justifyContent: 'center' }}>
                    {events.links.map((link, i) => (
                        <button
                            key={i}
                            disabled={!link.url}
                            onClick={() => link.url && router.get(link.url, {}, { preserveState: true })}
                            dangerouslySetInnerHTML={{ __html: link.label }}
                            className={`btn btn-sm ${link.active ? 'btn-primary' : 'btn-ghost'}`}
                        />
                    ))}
                </div>
            )}
        </AppLayout>
    );
}
