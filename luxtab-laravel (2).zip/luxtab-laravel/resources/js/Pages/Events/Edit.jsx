import { Head, Link, useForm, router } from '@inertiajs/react';
import { useState } from 'react';
import AppLayout from '../../Layouts/AppLayout';
import { Card, CardHeader, Button, TextInput, Select, FieldError } from '../../Components/UI';

function CriteriaSection({ event, criteriaWeightTotal }) {
    const { data, setData, post, processing, errors, reset } = useForm({ name: '', max_score: '', description: '' });
    const total = Number(criteriaWeightTotal);
    const onTarget = Math.abs(total - 100) < 0.01;

    const submit = (e) => {
        e.preventDefault();
        post(`/events/${event.event_id}/criteria`, { onSuccess: () => reset() });
    };

    const remove = (criterion) => {
        if (confirm(`Remove "${criterion.name}"?`)) router.delete(`/events/${event.event_id}/criteria/${criterion.criterion_id}`);
    };

    return (
        <Card header={<CardHeader icon="ri-scales-3-line" title="Scoring criteria" subtitle="Max score = weight — should sum to 100" right={
            <span className={`weight-badge`} style={!onTarget ? { background: 'var(--fire-bg)', color: 'var(--fire)' } : {}}>{total.toFixed(2)}%</span>
        } />}>
            <div className="card-pad">
                <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 16 }}>
                    {event.scoring_criteria?.map((c, i) => (
                        <div key={c.criterion_id} className="criteria-row" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                                <span className="criteria-num">{i + 1}</span>
                                <span style={{ fontWeight: 600 }}>{c.name}</span>
                                <span style={{ color: 'var(--text-muted)', fontSize: 12 }}>max {c.max_score} pts</span>
                            </div>
                            <button onClick={() => remove(c)} className="btn btn-ghost btn-sm"><i className="ri-delete-bin-line" /></button>
                        </div>
                    ))}
                    {(!event.scoring_criteria || event.scoring_criteria.length === 0) && (
                        <p style={{ fontSize: 13, color: 'var(--text-muted)', fontStyle: 'italic' }}>No criteria yet.</p>
                    )}
                </div>

                <form onSubmit={submit} style={{ display: 'flex', gap: 8, alignItems: 'flex-start' }}>
                    <div style={{ flex: 1 }}>
                        <TextInput placeholder="Criterion name" value={data.name} onChange={(e) => setData('name', e.target.value)} />
                        <FieldError>{errors.name}</FieldError>
                    </div>
                    <div style={{ width: 110 }}>
                        <TextInput type="number" step="0.01" placeholder="Max pts" value={data.max_score} onChange={(e) => setData('max_score', e.target.value)} />
                        <FieldError>{errors.max_score}</FieldError>
                    </div>
                    <Button type="submit" variant="secondary" disabled={processing} icon="ri-add-line">Add</Button>
                </form>
            </div>
        </Card>
    );
}

function ParticipantsSection({ event, institutes }) {
    const currentIds = (event.participants ?? []).map((p) => p.institute_id);
    const [selected, setSelected] = useState(currentIds);
    const [saving, setSaving] = useState(false);

    const toggle = (id) => setSelected((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
    const save = () => {
        setSaving(true);
        router.put(`/events/${event.event_id}/participants`, { institute_ids: selected }, { onFinish: () => setSaving(false) });
    };

    return (
        <Card header={<CardHeader icon="ri-building-2-line" title="Participating institutes" subtitle={`${selected.length} selected`} />}>
            <div className="card-pad">
                <div className="institute-grid" style={{ marginBottom: 16 }}>
                    {institutes.map((inst) => (
                        <label key={inst.id} className={`institute-card ${selected.includes(inst.id) ? 'selected' : ''}`}>
                            <input type="checkbox" checked={selected.includes(inst.id)} onChange={() => toggle(inst.id)} />
                            <div className="institute-color-bar" style={{ background: inst.color_hex }} />
                            <div className="institute-card-body">
                                <strong>{inst.code}</strong>
                                <small>{inst.name}</small>
                            </div>
                            <i className="ri-checkbox-circle-fill check-icon" />
                        </label>
                    ))}
                </div>
                <Button variant="secondary" onClick={save} disabled={saving} icon="ri-save-line">Save participants</Button>
            </div>
        </Card>
    );
}

function JudgesSection({ event, judgeUsers }) {
    const { data, setData, post, processing, reset } = useForm({ user_id: '', name: '', title: '' });

    const submit = (e) => {
        e.preventDefault();
        post(`/events/${event.event_id}/judges`, { onSuccess: () => reset() });
    };
    const remove = (judge) => {
        if (confirm(`Remove ${judge.name} from the panel?`)) router.delete(`/events/${event.event_id}/judges/${judge.id}`);
    };

    return (
        <Card header={<CardHeader icon="ri-user-star-line" title="Judge panel" subtitle="Registered or guest judges" />}>
            <div className="card-pad">
                <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 16 }}>
                    {event.judges?.map((j) => (
                        <div key={j.id} className="staff-item" style={{ cursor: 'default' }}>
                            <div className="staff-avatar">{j.name.slice(0, 2).toUpperCase()}</div>
                            <div>
                                <strong>{j.name}</strong>
                                <small>{!j.user_id ? 'Guest judge' : (j.title ?? 'Registered')}</small>
                            </div>
                            <button onClick={() => remove(j)} className="btn btn-ghost btn-sm" style={{ marginLeft: 'auto' }}><i className="ri-delete-bin-line" /></button>
                        </div>
                    ))}
                </div>

                <form onSubmit={submit} style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                    <Select value={data.user_id} onChange={(e) => setData('user_id', e.target.value)}>
                        <option value="">— Guest judge (no account) —</option>
                        {judgeUsers.map((u) => <option key={u.user_id} value={u.user_id}>{u.name}</option>)}
                    </Select>
                    {!data.user_id && (
                        <div className="form-grid-2">
                            <TextInput placeholder="Guest judge name" value={data.name} onChange={(e) => setData('name', e.target.value)} />
                            <TextInput placeholder="Title / affiliation" value={data.title} onChange={(e) => setData('title', e.target.value)} />
                        </div>
                    )}
                    <Button type="submit" variant="secondary" disabled={processing} icon="ri-add-line">Add judge</Button>
                </form>
            </div>
        </Card>
    );
}

function RankPointsSection({ event }) {
    const initial = event.rank_point_configs?.length
        ? event.rank_point_configs.map((r) => ({ rank_position: r.rank_position, points: r.points }))
        : [{ rank_position: 1, points: '' }, { rank_position: 2, points: '' }, { rank_position: 3, points: '' }];
    const [rows, setRows] = useState(initial);
    const [saving, setSaving] = useState(false);

    const updateRow = (i, field, value) => setRows((prev) => prev.map((r, idx) => (idx === i ? { ...r, [field]: value } : r)));
    const save = () => {
        setSaving(true);
        router.put(`/events/${event.event_id}/rank-points`, { ranks: rows }, { onFinish: () => setSaving(false) });
    };

    return (
        <Card header={<CardHeader icon="ri-medal-line" title="Rank → points" subtitle="Conversion table for Level 3" />}>
            <div className="card-pad points-grid" style={{ gridTemplateColumns: '1fr' }}>
                {rows.map((row, i) => (
                    <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                        <span style={{ fontSize: 13, color: 'var(--text-muted)', width: 60 }}>Rank {row.rank_position}</span>
                        <TextInput type="number" step="0.01" placeholder="Points" value={row.points} onChange={(e) => updateRow(i, 'points', e.target.value)} style={{ maxWidth: 120 }} />
                    </div>
                ))}
                <div style={{ display: 'flex', gap: 8, marginTop: 8 }}>
                    <Button variant="ghost" size="sm" onClick={() => setRows((p) => [...p, { rank_position: p.length + 1, points: '' }])}>+ Add rank</Button>
                    <Button variant="secondary" size="sm" onClick={save} disabled={saving}>Save table</Button>
                </div>
            </div>
        </Card>
    );
}

export default function EventsEdit({ event, institutes, judgeUsers, criteriaWeightTotal }) {
    return (
        <AppLayout title={event.name}>
            <Head title={`Configure — ${event.name}`} />

            <Link href={`/events/${event.event_id}`} className="back-link"><i className="ri-arrow-left-line" /> Back to event</Link>

            <div className="page-header">
                <div>
                    <h1 className="page-title"><i className="ri-settings-3-line" /> {event.name}</h1>
                    <p className="page-subtitle">Configure scoring, participants, and staff</p>
                </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(360px, 1fr))', gap: 20 }}>
                {event.scoring_type === 'criteria_based' ? (
                    <CriteriaSection event={event} criteriaWeightTotal={criteriaWeightTotal} />
                ) : (
                    <Card header={<CardHeader icon="ri-file-list-3-line" title="By-round event" />}>
                        <div className="card-pad">
                            <p style={{ fontSize: 13, color: 'var(--text-muted)' }}>
                                This event doesn't use a judge panel — enter results directly from the Tabulation screen once participants are set.
                            </p>
                        </div>
                    </Card>
                )}

                <ParticipantsSection event={event} institutes={institutes} />
                {event.scoring_type === 'criteria_based' && <JudgesSection event={event} judgeUsers={judgeUsers} />}
                {event.scoring_method === 'rank_based' && <RankPointsSection event={event} />}
            </div>
        </AppLayout>
    );
}
