import { Head, useForm } from '@inertiajs/react';
import AppLayout from '../../Layouts/AppLayout';
import { Card, Button, Label, TextInput, Select, FieldError } from '../../Components/UI';

const CATEGORY_ICON = { academic: ['ri-book-open-line', 'academic'], special: ['ri-star-line', 'special'], sports: ['ri-basketball-line', ''], 'socio-cultural': ['ri-drama-line', ''] };

export default function EventsCreate({ seasons, categories, tabulators }) {
    const { data, setData, post, processing, errors } = useForm({
        season_id: '', event_category_id: '', name: '', description: '',
        type: 'academic', participation_type: 'institute',
        scoring_type: 'criteria_based', scoring_method: 'points_based',
        venue: '', schedule: '', tabulator_id: '',
    });

    const selectedSeason = seasons.find((s) => String(s.id) === String(data.season_id));
    const categoryOptions = categories.filter((c) => !selectedSeason || c.program === selectedSeason.program);

    const submit = (e) => {
        e.preventDefault();
        post('/events');
    };

    return (
        <AppLayout title="Create event">
            <Head title="Create event" />

            <div className="wizard-steps">
                <div className="wizard-step active"><span className="step-num">1</span> Event details</div>
                <div className="wizard-step"><span className="step-num">2</span> Criteria &amp; participants</div>
            </div>

            <Card className="card-pad" style={{ maxWidth: 720 }}>
                <div className="wizard-panel-header">
                    <h2><i className="ri-calendar-event-line" /> New event</h2>
                    <p>Set the core details — you'll configure scoring criteria, participants, and judges next.</p>
                </div>

                <form onSubmit={submit}>
                    <div className="section-label">Season &amp; category</div>
                    <div className="form-grid-2">
                        <div className="form-group">
                            <Label htmlFor="season_id">Season</Label>
                            <Select id="season_id" value={data.season_id} onChange={(e) => setData('season_id', e.target.value)}>
                                <option value="">Select a season…</option>
                                {seasons.map((s) => <option key={s.id} value={s.id}>{s.label} ({s.program.toUpperCase()})</option>)}
                            </Select>
                            <FieldError>{errors.season_id}</FieldError>
                        </div>
                        <div className="form-group">
                            <Label htmlFor="event_category_id">Category</Label>
                            <Select id="event_category_id" value={data.event_category_id} onChange={(e) => setData('event_category_id', e.target.value)}>
                                <option value="">Select a category…</option>
                                {categoryOptions.map((c) => <option key={c.id} value={c.id}>{c.name} ({c.weight_pct}% weight)</option>)}
                            </Select>
                            <FieldError>{errors.event_category_id}</FieldError>
                        </div>
                    </div>

                    <div className="section-label">Event info</div>
                    <div className="form-group">
                        <Label htmlFor="name">Event name</Label>
                        <TextInput id="name" value={data.name} onChange={(e) => setData('name', e.target.value)} placeholder="e.g. Dance Sport Showdown" />
                        <FieldError>{errors.name}</FieldError>
                    </div>
                    <div className="form-group">
                        <Label htmlFor="description">Description</Label>
                        <textarea id="description" rows={3} value={data.description} onChange={(e) => setData('description', e.target.value)} className="form-control" />
                    </div>

                    <div className="category-selector-grid" style={{ marginBottom: 16 }}>
                        {['academic', 'special', 'sports'].map((t) => {
                            const [icon, cls] = CATEGORY_ICON[t] ?? ['ri-shapes-line', ''];
                            return (
                                <label key={t} className={`category-card ${data.type === t ? 'selected' : ''}`}>
                                    <input type="radio" name="type" checked={data.type === t} onChange={() => setData('type', t)} />
                                    <div className={`category-card-icon ${cls}`}><i className={icon} /></div>
                                    <div className="category-card-body">
                                        <h3 style={{ textTransform: 'capitalize' }}>{t}</h3>
                                        <p>Classify this event as {t}</p>
                                    </div>
                                    <i className="ri-checkbox-circle-fill category-check" />
                                </label>
                            );
                        })}
                    </div>

                    <div className="form-grid-2">
                        <div className="form-group">
                            <Label htmlFor="participation_type">Participation</Label>
                            <Select id="participation_type" value={data.participation_type} onChange={(e) => setData('participation_type', e.target.value)}>
                                <option value="institute">By institute</option>
                                <option value="team">By team</option>
                                <option value="individual">Individual</option>
                            </Select>
                        </div>
                        <div className="form-group">
                            <Label htmlFor="tabulator_id">Designated Tabulator</Label>
                            <Select id="tabulator_id" value={data.tabulator_id} onChange={(e) => setData('tabulator_id', e.target.value)}>
                                <option value="">Assign later…</option>
                                {tabulators.map((t) => <option key={t.user_id} value={t.user_id}>{t.name}</option>)}
                            </Select>
                        </div>
                    </div>

                    <div className="section-label">Scoring</div>
                    <div className="scoring-type-selector" style={{ marginBottom: 16 }}>
                        <label className={`scoring-mode-card ${data.scoring_type === 'criteria_based' ? 'selected' : ''}`}>
                            <input type="radio" checked={data.scoring_type === 'criteria_based'} onChange={() => setData('scoring_type', 'criteria_based')} />
                            <div className="mode-icon criteria"><i className="ri-user-star-line" /></div>
                            <div className="mode-body">
                                <h4>Criteria-based</h4>
                                <p>Judges score each participant per criterion (Judge Interface).</p>
                            </div>
                        </label>
                        <label className={`scoring-mode-card ${data.scoring_type === 'by_round' ? 'selected' : ''}`}>
                            <input type="radio" checked={data.scoring_type === 'by_round'} onChange={() => setData('scoring_type', 'by_round')} />
                            <div className="mode-icon"><i className="ri-file-list-3-line" /></div>
                            <div className="mode-body">
                                <h4>By-round</h4>
                                <p>Tabulator enters each participant's result directly.</p>
                            </div>
                        </label>
                    </div>

                    <div className="form-group">
                        <Label htmlFor="scoring_method">Scoring method</Label>
                        <Select id="scoring_method" value={data.scoring_method} onChange={(e) => setData('scoring_method', e.target.value)}>
                            <option value="points_based">Points-based (score carries forward — LMC style)</option>
                            <option value="rank_based">Rank-based (rank converts to points — ARSO style)</option>
                        </Select>
                    </div>

                    <div className="section-label">Schedule</div>
                    <div className="form-grid-2">
                        <div className="form-group">
                            <Label htmlFor="venue">Venue</Label>
                            <TextInput id="venue" value={data.venue} onChange={(e) => setData('venue', e.target.value)} />
                        </div>
                        <div className="form-group">
                            <Label htmlFor="schedule">Schedule</Label>
                            <TextInput id="schedule" type="datetime-local" value={data.schedule} onChange={(e) => setData('schedule', e.target.value)} />
                        </div>
                    </div>

                    <div className="wizard-nav">
                        <span />
                        <Button type="submit" disabled={processing} icon="ri-arrow-right-line">Create &amp; continue</Button>
                    </div>
                </form>
            </Card>
        </AppLayout>
    );
}
