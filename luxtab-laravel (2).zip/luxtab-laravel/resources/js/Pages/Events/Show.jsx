import { Head, Link } from '@inertiajs/react';
import AppLayout from '../../Layouts/AppLayout';
import { Card, CardHeader, Badge, Button, EmptyState } from '../../Components/UI';

const STATUS_TONE = { draft: 'draft', ongoing: 'open', completed: 'finalized', cancelled: 'danger', rescheduled: 'warning' };

export default function EventsShow({ event, can }) {
    return (
        <AppLayout title={event.name}>
            <Head title={event.name} />

            <Card style={{ marginBottom: 20 }}>
                <div className="detail-hero">
                    <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginBottom: 10 }}>
                        <Badge tone={STATUS_TONE[event.status] ?? 'closed'}>{event.status}</Badge>
                        {event.is_finalized && <Badge tone="finalized"><i className="ri-checkbox-circle-line" /> Finalized</Badge>}
                        <span className="badge badge-criteria">{event.category?.program?.toUpperCase()} · {event.category?.name}</span>
                    </div>
                    <h1 className="page-title" style={{ marginBottom: 4 }}>{event.name}</h1>
                    {event.description && <p style={{ color: 'var(--text-secondary)', fontSize: 13.5 }}>{event.description}</p>}

                    <div className="detail-meta-grid">
                        <div className="detail-meta-item">
                            <span className="detail-meta-label">Venue</span>
                            <span className="detail-meta-value"><i className="ri-map-pin-line" /> {event.venue ?? '—'}</span>
                        </div>
                        <div className="detail-meta-item">
                            <span className="detail-meta-label">Schedule</span>
                            <span className="detail-meta-value"><i className="ri-calendar-line" /> {event.schedule ? new Date(event.schedule).toLocaleString() : '—'}</span>
                        </div>
                        <div className="detail-meta-item">
                            <span className="detail-meta-label">Scoring</span>
                            <span className="detail-meta-value"><i className="ri-scales-3-line" /> {event.scoring_method === 'rank_based' ? 'Rank-based' : 'Points-based'}</span>
                        </div>
                    </div>
                </div>
                <div className="card-pad" style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
                    {can.update && <Link href={`/events/${event.event_id}/edit`}><Button variant="secondary" icon="ri-settings-3-line">Configure</Button></Link>}
                    {can.tabulate && <Link href={`/events/${event.event_id}/tabulation`}><Button icon="ri-bar-chart-box-line">Tabulation</Button></Link>}
                </div>
            </Card>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: 20 }}>
                <Card header={<CardHeader icon="ri-team-line" title="Participants" />}>
                    <div className="card-pad">
                        {event.participants?.length ? (
                            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                                {event.participants.map((p) => (
                                    <div key={p.participant_id} style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13.5 }}>
                                        <span style={{ width: 9, height: 9, borderRadius: '50%', background: p.institute?.color_hex, flexShrink: 0 }} />
                                        {p.name}
                                    </div>
                                ))}
                            </div>
                        ) : <EmptyState icon="ri-team-line" title="None assigned yet" />}
                    </div>
                </Card>

                {event.scoring_type === 'criteria_based' ? (
                    <Card header={<CardHeader icon="ri-user-star-line" title="Judge panel" />}>
                        <div className="card-pad">
                            {event.judges?.length ? (
                                <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                                    {event.judges.map((j) => (
                                        <div key={j.id} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', fontSize: 13.5 }}>
                                            <span>{j.name} {!j.user_id && <span className="badge badge-warning" style={{ marginLeft: 6 }}>Guest</span>}</span>
                                            {j.user_id && <Link href={`/events/${event.event_id}/judges/${j.id}/scoring`} style={{ fontSize: 12, fontWeight: 600 }}>Open scoring →</Link>}
                                        </div>
                                    ))}
                                </div>
                            ) : <EmptyState icon="ri-user-star-line" title="No judges assigned yet" />}
                        </div>
                    </Card>
                ) : (
                    <Card header={<CardHeader icon="ri-node-tree" title="Tournament bracket" />}>
                        <div className="card-pad">
                            <p style={{ fontSize: 13, color: 'var(--text-muted)', marginBottom: 10 }}>
                                {event.tournament ? `${event.tournament.format.replace('_', ' ')} — ${event.tournament.matches?.length ?? 0} matches` : 'No bracket generated yet.'}
                            </p>
                            <Link href={`/events/${event.event_id}/tournament`} style={{ fontSize: 13, fontWeight: 600 }}>
                                {event.tournament ? 'View bracket →' : 'Generate bracket →'}
                            </Link>
                        </div>
                    </Card>
                )}

                <Card header={<CardHeader icon="ri-scales-3-line" title="Scoring criteria" />}>
                    <div className="card-pad">
                        {event.scoring_criteria?.length ? (
                            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                                {event.scoring_criteria.map((c) => (
                                    <div key={c.criterion_id} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13.5 }}>
                                        <span>{c.name}</span>
                                        <span style={{ color: 'var(--text-muted)' }}>{c.max_score} pts</span>
                                    </div>
                                ))}
                            </div>
                        ) : <EmptyState icon="ri-scales-3-line" title="No criteria set" />}
                    </div>
                </Card>

                <Card header={<CardHeader icon="ri-shield-user-line" title="Staff" />}>
                    <div className="card-pad" style={{ fontSize: 13.5, display: 'flex', flexDirection: 'column', gap: 6 }}>
                        <div><span style={{ color: 'var(--text-muted)' }}>Organizer:</span> {event.organizer?.name}</div>
                        <div><span style={{ color: 'var(--text-muted)' }}>Tabulator:</span> {event.tabulator?.name ?? '—'}</div>
                    </div>
                </Card>
            </div>
        </AppLayout>
    );
}
