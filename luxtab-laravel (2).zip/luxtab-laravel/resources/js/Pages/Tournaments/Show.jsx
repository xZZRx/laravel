import { Head, router, useForm } from '@inertiajs/react';
import { useState } from 'react';
import AppLayout from '../../Layouts/AppLayout';
import { Card, CardHeader, Button, Badge, Select } from '../../Components/UI';

function MatchCard({ event, match }) {
    const [open, setOpen] = useState(false);
    const canRecord = match.participant_a_id && match.participant_b_id && match.status !== 'completed';

    const recordResult = (winnerId) => {
        router.post(`/events/${event.event_id}/matches/${match.match_id}/result`, { winner_id: winnerId }, { onSuccess: () => setOpen(false) });
    };

    return (
        <div className="card" style={{ width: 220, flexShrink: 0 }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '9px 12px', background: match.winner_id === match.participant_a_id ? 'var(--brand-dim)' : 'transparent', fontWeight: match.winner_id === match.participant_a_id ? 700 : 400 }}>
                <span style={{ fontSize: 13 }}>{match.participant_a?.name ?? (match.is_bye ? '—' : 'TBD')}</span>
                <span style={{ fontSize: 11, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)' }}>{match.score_a ?? ''}</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '9px 12px', borderTop: '1px solid var(--border)', background: match.winner_id === match.participant_b_id ? 'var(--brand-dim)' : 'transparent', fontWeight: match.winner_id === match.participant_b_id ? 700 : 400 }}>
                <span style={{ fontSize: 13 }}>{match.participant_b?.name ?? (match.is_bye ? '—' : 'TBD')}</span>
                <span style={{ fontSize: 11, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)' }}>{match.score_b ?? ''}</span>
            </div>
            {canRecord && (
                <div style={{ padding: '8px 12px', borderTop: '1px solid var(--border)' }}>
                    {!open ? (
                        <button onClick={() => setOpen(true)} style={{ fontSize: 11.5, color: 'var(--brand)', fontWeight: 600 }}>Record result</button>
                    ) : (
                        <div style={{ display: 'flex', gap: 6 }}>
                            <button onClick={() => recordResult(match.participant_a_id)} className="btn btn-ghost btn-xs" style={{ fontSize: 11 }}>A wins</button>
                            <button onClick={() => recordResult(match.participant_b_id)} className="btn btn-ghost btn-xs" style={{ fontSize: 11 }}>B wins</button>
                        </div>
                    )}
                </div>
            )}
        </div>
    );
}

function BracketGenerator({ event }) {
    const { data, setData, post, processing } = useForm({ format: 'single_elimination', seeded: false });

    const submit = (e) => {
        e.preventDefault();
        if (!confirm('Generate a bracket? This replaces any existing bracket for this event.')) return;
        post(`/events/${event.event_id}/tournament`);
    };

    return (
        <Card header={<CardHeader icon="ri-node-tree" title="Generate bracket" subtitle={`${event.participants?.length ?? 0} participants ready`} />}>
            <div className="card-pad" style={{ maxWidth: 380 }}>
                <form onSubmit={submit} style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                    <Select value={data.format} onChange={(e) => setData('format', e.target.value)}>
                        <option value="single_elimination">Single elimination</option>
                        <option value="double_elimination">Double elimination</option>
                        <option value="round_robin">Round robin</option>
                    </Select>
                    <Button type="submit" disabled={processing} icon="ri-magic-line">Generate</Button>
                </form>
            </div>
        </Card>
    );
}

export default function TournamentsShow({ event }) {
    const tournament = event.tournament;
    const rounds = tournament ? [...new Set(tournament.matches.map((m) => m.round_number))].sort((a, b) => a - b) : [];

    return (
        <AppLayout title={`Bracket — ${event.name}`}>
            <Head title={`Bracket — ${event.name}`} />

            {!tournament ? (
                <BracketGenerator event={event} />
            ) : (
                <>
                    <div className="page-header">
                        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                            <Badge tone="info">{tournament.format.replace('_', ' ')}</Badge>
                            <span style={{ fontSize: 12.5, color: 'var(--text-muted)' }}>{tournament.matches.length} matches</span>
                        </div>
                    </div>
                    <div style={{ display: 'flex', gap: 24, overflowX: 'auto', paddingBottom: 16 }}>
                        {rounds.map((round) => (
                            <div key={round} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
                                <div className="nav-section-label" style={{ color: 'var(--text-muted)', padding: 0 }}>Round {round}</div>
                                {tournament.matches.filter((m) => m.round_number === round).map((m) => (
                                    <MatchCard key={m.match_id} event={event} match={m} />
                                ))}
                            </div>
                        ))}
                    </div>
                </>
            )}
        </AppLayout>
    );
}
