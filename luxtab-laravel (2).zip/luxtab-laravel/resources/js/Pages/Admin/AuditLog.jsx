import { Head, router } from '@inertiajs/react';
import AppLayout from '../../Layouts/AppLayout';
import { Card, TextInput, EmptyState } from '../../Components/UI';

export default function AuditLog({ logs, filters }) {
    const setFilter = (key, value) => router.get('/admin/audit-log', { ...filters, [key]: value || undefined }, { preserveState: true });

    return (
        <AppLayout title="Audit log">
            <Head title="Audit log" />

            <div className="filter-row" style={{ marginBottom: 20 }}>
                <TextInput placeholder="Filter by action" defaultValue={filters.action} onBlur={(e) => setFilter('action', e.target.value)} style={{ width: 240 }} />
                <TextInput placeholder="Filter by target type (e.g. Event)" defaultValue={filters.target_type} onBlur={(e) => setFilter('target_type', e.target.value)} style={{ width: 240 }} />
            </div>

            <Card>
                {logs.data.length === 0 ? (
                    <EmptyState icon="ri-shield-check-line" title="No matching log entries" />
                ) : (
                    <div>
                        {logs.data.map((log) => (
                            <div key={log.log_id} className="audit-row">
                                <div className="audit-icon"><i className="ri-history-line" /></div>
                                <div style={{ flex: 1 }}>
                                    <div className="audit-action">{log.user?.name ?? 'System'} — {log.action}</div>
                                    <div className="audit-meta">
                                        {log.target_type && `${log.target_type}${log.target_id ? ` #${log.target_id}` : ''}`}
                                        {log.notes && ` · ${log.notes}`}
                                    </div>
                                </div>
                                <div className="audit-time">{new Date(log.performed_at).toLocaleString()}</div>
                            </div>
                        ))}
                    </div>
                )}
            </Card>
        </AppLayout>
    );
}
