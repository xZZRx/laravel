import { Head, Link, router } from '@inertiajs/react';
import AppLayout from '../../../Layouts/AppLayout';
import { Card, Badge, Button, Select, TextInput, EmptyState } from '../../../Components/UI';

const ROLE_LABELS = {
    admin: 'Admin', organizer: 'Organizer', tournament_manager: 'Tournament Manager',
    judge: 'Judge', tabulator: 'Tabulator', viewer: 'Viewer',
};

export default function AdminUsersIndex({ users, roles, filters }) {
    const setFilter = (key, value) => router.get('/admin/users', { ...filters, [key]: value || undefined }, { preserveState: true });
    const deactivate = (user) => {
        if (confirm(`Deactivate ${user.name}'s account?`)) router.delete(`/admin/users/${user.user_id}`);
    };

    return (
        <AppLayout title="User accounts">
            <Head title="User accounts" />

            <div className="page-header">
                <div className="filter-row">
                    <TextInput placeholder="Search…" defaultValue={filters.search} onBlur={(e) => setFilter('search', e.target.value)} style={{ width: 220 }} />
                    <Select value={filters.role ?? ''} onChange={(e) => setFilter('role', e.target.value)} style={{ width: 200 }}>
                        <option value="">All roles</option>
                        {roles.map((r) => <option key={r} value={r}>{ROLE_LABELS[r]}</option>)}
                    </Select>
                </div>
                <div className="page-header-right">
                    <Link href="/admin/users/create"><Button icon="ri-user-add-line">New account</Button></Link>
                </div>
            </div>

            <Card>
                {users.data.length === 0 ? (
                    <EmptyState icon="ri-team-line" title="No matching accounts" />
                ) : (
                    <div>
                        {users.data.map((u) => (
                            <div key={u.user_id} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '15px 22px', borderBottom: '1px solid var(--border)' }}>
                                <div>
                                    <div style={{ fontWeight: 600 }}>{u.name} <span style={{ color: 'var(--text-muted)', fontWeight: 400 }}>@{u.username}</span></div>
                                    <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{u.email} {u.institute && `· ${u.institute.name}`}</div>
                                </div>
                                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                                    {u.is_active ? <span className="role-pill">{ROLE_LABELS[u.role]}</span> : <Badge tone="danger">Deactivated</Badge>}
                                    {u.is_active && <button onClick={() => deactivate(u)} className="btn btn-ghost btn-xs"><i className="ri-user-unfollow-line" /></button>}
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </Card>
        </AppLayout>
    );
}
