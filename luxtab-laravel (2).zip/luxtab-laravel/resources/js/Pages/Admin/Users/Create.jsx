import { Head, useForm } from '@inertiajs/react';
import AppLayout from '../../../Layouts/AppLayout';
import { Card, Button, Label, TextInput, Select, FieldError } from '../../../Components/UI';

const ROLE_LABELS = {
    admin: 'Admin', organizer: 'Organizer', tournament_manager: 'Tournament Manager',
    judge: 'Judge', tabulator: 'Tabulator', viewer: 'Viewer',
};

export default function AdminUsersCreate({ roles, institutes }) {
    const { data, setData, post, processing, errors } = useForm({
        name: '', username: '', email: '', role: 'viewer', institute_id: '', password: '',
    });

    const submit = (e) => {
        e.preventDefault();
        post('/admin/users');
    };

    return (
        <AppLayout title="New user account">
            <Head title="New user account" />

            <Card className="card-pad" style={{ maxWidth: 520 }}>
                <form onSubmit={submit}>
                    <div className="form-group">
                        <Label htmlFor="name">Full name</Label>
                        <TextInput id="name" value={data.name} onChange={(e) => setData('name', e.target.value)} />
                        <FieldError>{errors.name}</FieldError>
                    </div>

                    <div className="form-grid-2">
                        <div className="form-group">
                            <Label htmlFor="username">Username</Label>
                            <TextInput id="username" value={data.username} onChange={(e) => setData('username', e.target.value)} />
                            <FieldError>{errors.username}</FieldError>
                        </div>
                        <div className="form-group">
                            <Label htmlFor="email">Email</Label>
                            <TextInput id="email" type="email" value={data.email} onChange={(e) => setData('email', e.target.value)} />
                            <FieldError>{errors.email}</FieldError>
                        </div>
                    </div>

                    <div className="form-grid-2">
                        <div className="form-group">
                            <Label htmlFor="role">Role</Label>
                            <Select id="role" value={data.role} onChange={(e) => setData('role', e.target.value)}>
                                {roles.map((r) => <option key={r} value={r}>{ROLE_LABELS[r]}</option>)}
                            </Select>
                        </div>
                        <div className="form-group">
                            <Label htmlFor="institute_id">Institute (optional)</Label>
                            <Select id="institute_id" value={data.institute_id} onChange={(e) => setData('institute_id', e.target.value)}>
                                <option value="">—</option>
                                {institutes.map((i) => <option key={i.id} value={i.id}>{i.name}</option>)}
                            </Select>
                        </div>
                    </div>

                    <div className="form-group">
                        <Label htmlFor="password">Temporary password</Label>
                        <TextInput id="password" type="text" value={data.password} onChange={(e) => setData('password', e.target.value)} placeholder="Leave blank to auto-generate" />
                        <FieldError>{errors.password}</FieldError>
                    </div>

                    <Button type="submit" disabled={processing} icon="ri-user-add-line">Create account</Button>
                </form>
            </Card>
        </AppLayout>
    );
}
