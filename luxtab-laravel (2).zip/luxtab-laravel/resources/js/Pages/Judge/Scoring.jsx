import { Head, router } from '@inertiajs/react';
import { useMemo, useState } from 'react';
import AppLayout from '../../Layouts/AppLayout';
import { Card, Button, Badge } from '../../Components/UI';

export default function JudgeScoring({ event, judge, criteria, participants, entries, signature, isLocked }) {
    const initial = useMemo(() => {
        const grid = {};
        participants.forEach((p) => {
            grid[p.participant_id] = {};
            criteria.forEach((c) => {
                const existing = entries?.[p.participant_id]?.[c.criterion_id];
                grid[p.participant_id][c.criterion_id] = existing ? String(existing.raw_score) : '';
            });
        });
        return grid;
    }, [entries, participants, criteria]);

    const [grid, setGrid] = useState(initial);
    const [saving, setSaving] = useState(false);
    const [rangeError, setRangeError] = useState(null);

    const setCell = (participantId, criterionId, value, max) => {
        setRangeError(value !== '' && Number(value) > Number(max) ? `Score can't exceed ${max} for this criterion.` : null);
        setGrid((prev) => ({ ...prev, [participantId]: { ...prev[participantId], [criterionId]: value } }));
    };

    const save = () => {
        const scores = [];
        for (const p of participants) {
            for (const c of criteria) {
                const val = grid[p.participant_id]?.[c.criterion_id];
                if (val !== '' && val !== undefined) scores.push({ participant_id: p.participant_id, criterion_id: c.criterion_id, raw_score: Number(val) });
            }
        }
        setSaving(true);
        router.post(`/events/${event.event_id}/judges/${judge.id}/scoring`, { signature, scores }, { onFinish: () => setSaving(false), preserveScroll: true });
    };

    const submitFinal = () => {
        if (!confirm('Submit and lock your scores? A Tabulator will need to reopen them for any further changes.')) return;
        router.post(`/events/${event.event_id}/judges/${judge.id}/submit`, {}, { preserveScroll: true });
    };

    const totalMax = criteria.reduce((sum, c) => sum + Number(c.max_score), 0);

    return (
        <AppLayout title={`Scoring — ${event.name}`}>
            <Head title={`Scoring — ${event.name}`} />

            <div className="score-entry-header">
                <div className="event-status-row">
                    <div className="event-status-badges">
                        <Badge tone={isLocked ? 'finalized' : 'warning'}>{isLocked ? 'Submitted & locked' : 'In progress'}</Badge>
                        <span className="event-completion"><i className="ri-scales-3-line" /> Max total: {totalMax} pts</span>
                    </div>
                    {!isLocked && (
                        <div style={{ display: 'flex', gap: 8 }}>
                            <Button variant="secondary" size="sm" onClick={save} disabled={saving} icon="ri-save-line">Save progress</Button>
                            <Button size="sm" onClick={submitFinal} icon="ri-lock-line">Submit &amp; lock</Button>
                        </div>
                    )}
                </div>
                {rangeError && <div className="alert alert-error" style={{ marginBottom: 14 }}><i className="ri-error-warning-line" /> {rangeError}</div>}
                <div className="scoring-rules-box">
                    <h4><i className="ri-information-line" /> Scoring rules</h4>
                    <p>Enter a score for each criterion, up to its listed maximum. Scores save as you go — submit only when every cell is complete.</p>
                </div>
            </div>

            <Card>
                <div className="score-table-wrapper">
                    <table className="score-table">
                        <thead>
                            <tr>
                                <th>Participant</th>
                                {criteria.map((c) => <th key={c.criterion_id}>{c.name} <span style={{ opacity: .6 }}>/{c.max_score}</span></th>)}
                                <th style={{ textAlign: 'right' }}>Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            {participants.map((p) => {
                                const rowTotal = criteria.reduce((sum, c) => sum + (Number(grid[p.participant_id]?.[c.criterion_id]) || 0), 0);
                                const isTop = false;
                                return (
                                    <tr key={p.participant_id} className={isTop ? 'score-row top-score' : ''}>
                                        <td>
                                            <div className="inst-badge">
                                                <strong><span className="inst-color-dot" style={{ background: p.institute?.color_hex }} /> {p.name}</strong>
                                            </div>
                                        </td>
                                        {criteria.map((c) => (
                                            <td key={c.criterion_id}>
                                                <input
                                                    type="number" min="0" max={c.max_score} step="0.01" disabled={isLocked}
                                                    value={grid[p.participant_id]?.[c.criterion_id] ?? ''}
                                                    onChange={(e) => setCell(p.participant_id, c.criterion_id, e.target.value, c.max_score)}
                                                    className="form-control score-input"
                                                />
                                            </td>
                                        ))}
                                        <td style={{ textAlign: 'right' }}><span className="effective-score">{rowTotal.toFixed(2)}</span></td>
                                    </tr>
                                );
                            })}
                        </tbody>
                    </table>
                </div>
            </Card>
        </AppLayout>
    );
}
