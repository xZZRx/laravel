import { Head, router, useForm } from '@inertiajs/react';
import { useState } from 'react';
import AppLayout from '../../Layouts/AppLayout';
import StandingsTable from '../../Components/StandingsTable';
import { Card, CardHeader, Button, Badge, Select, TextInput, FieldError } from '../../Components/UI';

function DeductionForm({ event, participants }) {
    const [open, setOpen] = useState(false);
    const { data, setData, post, processing, errors, reset } = useForm({ institute_id: '', level: 'event', judge_id: '', value: '', reason: '' });

    const submit = (e) => {
        e.preventDefault();
        post(`/events/${event.event_id}/deductions`, { onSuccess: () => { reset(); setOpen(false); } });
    };

    if (!open) {
        return <Button variant="secondary" size="sm" onClick={() => setOpen(true)} icon="ri-subtract-line">Apply deduction</Button>;
    }

    return (
        <div className="criteria-row">
            <form onSubmit={submit} style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                <div className="form-grid-2">
                    <div>
                        <Select value={data.institute_id} onChange={(e) => setData('institute_id', e.target.value)}>
                            <option value="">Institute…</option>
                            {participants.map((p) => <option key={p.institute_id} value={p.institute_id}>{p.institute?.name ?? p.name}</option>)}
                        </Select>
                        <FieldError>{errors.institute_id}</FieldError>
                    </div>
                    <Select value={data.level} onChange={(e) => setData('level', e.target.value)}>
                        <option value="judge">Judge level</option>
                        <option value="event">Event level</option>
                        <option value="overall">Overall level</option>
                    </Select>
                </div>
                {data.level === 'judge' && <TextInput placeholder="Judge ID (see judge panel)" value={data.judge_id} onChange={(e) => setData('judge_id', e.target.value)} />}
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: 10 }}>
                    <div>
                        <TextInput type="number" step="0.01" placeholder="Points" value={data.value} onChange={(e) => setData('value', e.target.value)} />
                        <FieldError>{errors.value}</FieldError>
                    </div>
                    <div>
                        <TextInput placeholder="Reason" value={data.reason} onChange={(e) => setData('reason', e.target.value)} />
                        <FieldError>{errors.reason}</FieldError>
                    </div>
                </div>
                <div style={{ display: 'flex', gap: 8 }}>
                    <Button type="submit" size="sm" disabled={processing}>Apply</Button>
                    <Button type="button" variant="ghost" size="sm" onClick={() => setOpen(false)}>Cancel</Button>
                </div>
            </form>
        </div>
    );
}

export default function TabulationShow({ event, standings, judgesStatus, allJudgesSubmitted }) {
    const finalize = () => {
        if (confirm('Finalize standings for this event? This locks scores and updates the Overall Score.')) {
            router.post(`/events/${event.event_id}/tabulation/finalize`);
        }
    };
    const reopen = () => { if (confirm('Reopen this event for corrections?')) router.post(`/events/${event.event_id}/tabulation/reopen`); };
    const toggleVisibility = () => router.post(`/events/${event.event_id}/tabulation/toggle-visibility`);

    const rows = standings.map((s, i) => ({ key: s.institute_id, rank: i + 1, name: s.institute, score: Number(s.score).toFixed(2) }));

    return (
        <AppLayout title={`Tabulation — ${event.name}`}>
            <Head title={`Tabulation — ${event.name}`} />

            <div className="page-header">
                <div style={{ display: 'flex', gap: 8 }}>
                    <Badge tone={event.is_finalized ? 'finalized' : 'warning'}>{event.is_finalized ? 'Finalized' : 'Not finalized'}</Badge>
                    <Badge tone={event.leaderboard_visible ? 'open' : 'closed'}>{event.leaderboard_visible ? 'Leaderboard visible' : 'Leaderboard hidden'}</Badge>
                </div>
                <div className="page-header-right">
                    <Button variant="secondary" onClick={toggleVisibility} icon={event.leaderboard_visible ? 'ri-eye-off-line' : 'ri-eye-line'}>
                        {event.leaderboard_visible ? 'Hide from leaderboard' : 'Show on leaderboard'}
                    </Button>
                    {event.is_finalized ? (
                        <Button variant="danger" onClick={reopen} icon="ri-lock-unlock-line">Reopen</Button>
                    ) : (
                        <Button onClick={finalize} disabled={!allJudgesSubmitted} icon="ri-flag-line">Finalize standings</Button>
                    )}
                </div>
            </div>

            {!allJudgesSubmitted && !event.is_finalized && (
                <div className="alert alert-error" style={{ marginBottom: 20 }}>
                    <i className="ri-time-line" /> Waiting on {judgesStatus.filter((j) => !j.has_submitted).length} judge(s) to submit before this event can be finalized.
                </div>
            )}

            <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 20 }}>
                <div>
                    <div className="section-label">Current standings</div>
                    <Card>
                        <div className="card-pad">
                            <StandingsTable rows={rows} scoreLabel="Event score" emptyMessage="No scores entered yet." />
                        </div>
                    </Card>
                </div>

                <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
                    {event.scoring_type === 'criteria_based' && (
                        <Card header={<CardHeader icon="ri-user-star-line" title="Judge status" />}>
                            <div className="card-pad" style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                                {judgesStatus.map((j) => (
                                    <div key={j.id} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13 }}>
                                        <span>{j.name} {j.is_guest && <span style={{ color: 'var(--fire)' }}>(guest)</span>}</span>
                                        <Badge tone={j.has_submitted ? 'finalized' : 'closed'}>{j.has_submitted ? 'Submitted' : `${j.entries_count} entries`}</Badge>
                                    </div>
                                ))}
                            </div>
                        </Card>
                    )}

                    <Card header={<CardHeader icon="ri-subtract-line" title="Deductions" />}>
                        <div className="card-pad" style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                            <DeductionForm event={event} participants={event.participants ?? []} />
                            {event.deductions?.map((d) => (
                                <div key={d.deduction_id} className="criteria-row" style={{ fontSize: 12.5 }}>
                                    <span style={{ fontWeight: 700, color: 'var(--red-600)' }}>-{d.value} pts</span> ({d.level}) — {d.reason}
                                </div>
                            ))}
                        </div>
                    </Card>
                </div>
            </div>
        </AppLayout>
    );
}
