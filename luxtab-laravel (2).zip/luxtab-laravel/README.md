# LuxTab — Laravel + Inertia + React

An automated score tabulation and leaderboard system for Tangub City Global College's (TCGC) Luxmundis Cup and ARSO Festival, rebuilt on Laravel 11 + Inertia.js + React + Tailwind per Thesis Ch.3.2.2, with the scoring engine implementing the three-level computation model from Ch.4.4.1.

## Design

The visual design is ported from the original PHP build's `assets/css/app.css` (a genuinely well-crafted, custom system — forest-green identity with warm fire-orange accents, Playfair Display + Outfit + DM Mono typography, Remix Icon iconography), not reinvented. Same tokens, same component classes (`.btn`, `.card`, `.badge-*`, `.rank-medal`, `.standings-table`, the podium, the wizard steps, the split-screen login), same sidebar/nav structure — now implemented as React components in `resources/js/Components/UI.jsx` and `resources/css/app.css` instead of PHP includes and a static stylesheet. Dark mode (`data-theme="dark"`, toggled from the sidebar footer, persisted to `localStorage`) carries over too.

## Quick start (Laragon)

This project's source code is complete and hand-written, but **`composer install` was never run** — the sandbox this was built in can't reach Packagist. Everything below is the normal first run.

1. Drop this folder into `laragon/www/luxtab` (or wherever your Laragon `www` root is).
2. Open a terminal in the project folder and run:
   ```bash
   composer install
   npm install
   copy .env.example .env        # (or `cp` on macOS/Linux)
   php artisan key:generate
   ```
3. In `.env`, confirm `DB_DATABASE=luxtab` (or whatever you want) and create that database in HeidiSQL/phpMyAdmin — Laravel won't create it for you.
4. Run migrations and seed demo data:
   ```bash
   php artisan migrate --seed
   php artisan storage:link
   ```
5. Build the frontend:
   ```bash
   npm run build       # one-off production build
   # — or, while actively developing —
   npm run dev          # in a separate terminal, for hot reload
   ```
6. Visit `http://luxtab.test` (Laragon auto-virtual-hosts folder names) or `php artisan serve` and visit `http://127.0.0.1:8000`.

### Demo accounts
Every seeded account uses the password **`Luxtab@2026`**:

| Username | Role |
|---|---|
| `admin` | Admin |
| `organizer` | Organizer |
| `tmanager` | Tournament Manager |
| `judge1`, `judge2`, `judge3` | Judge |
| `tabulator` | Tabulator |
| `viewer` | Viewer |

The seeder also creates one fully finalized ARSO event (criteria-based, rank-based — exercises Level 1→2→3) and one finalized LMC event (by-round, points-based), so `/leaderboard` has real standings to show immediately.

**Before your defense:** open `database/seeders/InstituteSeeder.php` and replace the six placeholder institute names with TCGC's real six — I didn't have those names in the thesis text I was given.

## Thesis-to-code traceability

| Thesis section | What it says | Where it lives |
|---|---|---|
| Ch.3.2.2 (stack) | Laravel + Inertia.js + React + Vite + Tailwind + MySQL | Whole project; `package.json`, `composer.json` |
| Figure 15 (use cases) | 6 roles: Admin, Organizer, TM, Judge, Tabulator, Viewer | `app/Enums/Role.php`, `app/Http/Middleware/EnsureUserHasRole.php` |
| Figure 15, extends | "Warn: Account Not Found" vs "Warn: Invalid Credentials" | `app/Http/Requests/Auth/LoginRequest.php` |
| Figure 16 (ERD) | All 12 entities | `database/migrations/*` — one migration per entity, named to match |
| Ch.4.4.1 Level 1 | Judge Total = sum of raw scores (criterion max = weight) | `ScoreComputationService::judgeTotal()` |
| Ch.4.4.1 Level 2 | Event Score = average of judge totals, minus event deductions, ranked | `ScoreComputationService::eventScoreForParticipant()` / `recomputeEventStandings()` |
| Ch.4.4.1 Level 3 | Overall Score = Σ(event input × category weight) − overall deductions | `ScoreComputationService::recomputeSeasonStandings()` |
| Ch.4.4.1 rank conversion | rank_based events convert rank→points via a configured table | `ScoreComputationService::convertRankToPoints()`, `rank_point_configs` table |
| ERD DEDUCTION.level | judge / event / overall | `Deduction` model constants, `DeductionController` |
| Ch.1.1 | ARSO weights: Academic 30% / Special 50% / Socio-Cultural 20% | `database/seeders/EventCategorySeeder.php` |
| Module 3 | Single/double elimination, round robin | `BracketGenerationService` |
| Figure 17 (architecture) | 4-layer architecture, optimistic locking, audit logging | Layer 1–2 = React pages/roles; Layer 3 = `app/Services/*`; Layer 4 = migrations. Optimistic locking = the `signature` hash in `JudgeScoringController`. |

## What changed from the previous (plain-PHP) build

The previous system worked but only implemented the Luxmundis Cup with an Olympic-style medal-points table, not the paper's three-level, category-weighted model, and didn't have ARSO Festival support at all. Both of those are now real: `event_categories.weight_pct`, `events.scoring_method` (rank_based/points_based), and the full `ScoreComputationService` pipeline. See the full comparison from earlier in this conversation for the complete list.

## Known simplifications (be ready to speak to these at defense)

- **Double-elimination brackets**: the winners bracket auto-generates and auto-advances exactly like single elimination. The losers bracket is created with a reasonable number of rounds/slots, but isn't auto-wired to receive winners-bracket losers — a Tournament Manager seeds it manually. Single elimination and round robin are fully automatic, including standard seeding.
- **LMC category weights**: the thesis only states ARSO's weights (30/50/20). LMC's three categories are seeded at an equal 33.33/33.33/33.34 split as an editable placeholder — update `EventCategorySeeder.php` (or the Settings UI, once built) with the real SSC-confirmed split.
- **Institute names**: placeholders in `InstituteSeeder.php` — see Quick Start above.
- **Not yet built**: PDF report export, an in-app Settings screen, Institutes/Seasons management UI, and avatar/logo file uploads (the storage directories exist; the upload UI doesn't yet). The previous system's `export_pdf.php`, `settings.php`, `institutes.php`, and `lmc_years.php` don't have Laravel equivalents yet — their sidebar nav entries are intentionally left out (`resources/js/Layouts/AppLayout.jsx`) rather than linking to something that doesn't exist. Add them back to the `buildNav()` groups there as each page gets built.
- **Team/individual participation**: the data model supports it (`events.participation_type`), but standings computation is scoped to institute-based participants, matching the thesis's actual scope (TCGC's six institutes). A team/individual participant won't appear on the leaderboard.

## Project structure

Standard Laravel 11 layout. The parts worth knowing about specifically:
- `app/Services/ScoreComputationService.php` — the scoring engine (Ch.4.4.1)
- `app/Services/BracketGenerationService.php` — bracket generation (Module 3)
- `database/migrations/` — read top to bottom; each file's docblock explains its ERD mapping and any deliberate deviation
- `resources/js/Pages/` — one folder per feature area, matching `routes/web.php`
